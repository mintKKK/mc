<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING^E_DEPRECATED);
	function html_css(){ ?>
		<meta charset="utf-8">
			<!--编码格式-->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
			<!--移动优先-->
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<!--免得出现被上广告-->			
		<link href="http://images-10010175.file.myqcloud.com/ico.png" rel="shortcut icon" />
		<link rel="stylesheet" href="css/amazeui/amazeui.min.css" />		
<?php 
	}
	function html_js(){  ?>
		<noscript>
		<div style="width: 100%;height: 100%;position: absolute;background: #34495e;color: #ecf0f1;">
			<h1>&nbsp;&nbsp;&nbsp;<i class="icon icon-info-sign icon-2x"></i>&nbsp;很抱歉似乎你的浏览器不支持JS或出现错误！XD</h1>
			<h3 style="color: #bdc3c7;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;建议换个浏览器或者重新下载浏览器.</h3>
		</div>			
		</noscript>
		<!--不能加载js事件-->		
	<script type="text/javascript" src="js/jquery.min.js" ></script>
	<script type="text/javascript" src="js/amazeui/amazeui.min.js" ></script>
	<!--<script type="text/javascript" color="52, 73, 94" opacity='0.7' zIndex="-2" count="99" src="//github.atool.org/canvas-nest.min.js"></script>-->
<?php 	
	}
	function html_inside_css(){ ?>
		<meta charset="utf-8">
			<!--编码格式-->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
			<!--移动优先-->
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<!--免得出现被上广告-->
		<link href="http://images-10010175.file.myqcloud.com/ico.png" rel="shortcut icon" />
		<link rel="stylesheet" href="../css/amazeui/amazeui.min.css" />
<?php		
	}
	function html_inside_js(){ ?>
		<noscript>
		<div style="width: 100%;height: 100%;position: absolute;background: #34495e;color: #ecf0f1;">
			<h1>&nbsp;&nbsp;&nbsp;<i class="icon icon-info-sign icon-2x"></i>&nbsp;很抱歉似乎你的浏览器不支持JS或出现错误！XD</h1>
			<h3 style="color: #bdc3c7;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;建议换个浏览器或者重新下载浏览器.</h3>
		</div>			
		</noscript>
		<!--不能加载js事件-->		
	<script type="text/javascript" src="../js/jquery.min.js" ></script>
	<script type="text/javascript" src="../js/amazeui/amazeui.min.js" ></script>			
	<!--<script type="text/javascript" color="52, 73, 94" opacity='0.7' zIndex="-2" count="99" src="//github.atool.org/canvas-nest.min.js"></script>-->
<?php
	}
function change_password($mysqli,$info,$password,$username){
	$mode=$info['mode'];
	switch ($mode) {
		case 'none':
		$sql = "UPDATE skinme SET pass=? where user=?";
		$stmt_pass_1=$mysqli->prepare($sql);
		$md5_password=md5($password);
		$stmt_pass_1->bind_param("ss",$md5_password,$username);
		if($stmt_pass_1->execute()){
			$msg['mode']='2';
			$msg['msg']='[Oneskin]成功修改密码';
			$stmt_pass_1->close();		
			return $msg;			
		}else{
			$msg['mode']='1';
			$msg['msg']='[Oneskin]修改密码失败';
			$stmt_pass_1->close();	
			return $msg;			
		}
			break;
		case 'authme':		
		$salt = getRandChar(16);//获取16位散列
		$password_sha256 = hash('sha256', $password);
		$password_sha256 = hash("sha256", $password_sha256.$salt);//计算出sha256
		$password_sha256 = '$SHA$'.$salt.'$'.$password_sha256;
		$sql = "UPDATE ".$info['table']." SET ".$info['password']."=? where ".$info['username']."=?";//更新玩家Authme密码
		$stmt_pass_1=$mysqli->prepare($sql);		
		$user=strtolower($username);
		$stmt_pass_1->bind_param("ss",$password_sha256,$username);
		if($stmt_pass_1->execute()){
			$msg['mode']='2';
			$msg['msg']='[Authme]成功修改密码';
			$stmt_pass_1->close();	
			return $msg;			
		}else{
			$msg['mode']='1';
			$msg['msg']='[Authme]修改密码失败';
			$stmt_pass_1->close();	
			return $msg;				
		}				
			break;
		case 'beelogin':
		$salt = getRandChar(6);//获取随机6位散列
		$password_salt = md5(md5($password).$salt);//计算出密码
		$sql = "UPDATE ".$info['table']." SET ".$info['password']."=?,".$info['password_salt']."=? where ".$info['username']."=?";//更新玩家beelogin密码
		$stmt_pass=$mysqli->prepare($sql);		
		$stmt_pass->bind_param("sss",$password_salt,$salt,$username);
		if($stmt_pass->execute()){
			$msg['mode']='2';
			$msg['msg']='[Beelogin]成功修改密码';
			$stmt_pass->close();
			return $msg;
		}else{
			$msg['mode']='1';
			$msg['msg']='[Beelogin]修改密码失败请重试';
			$stmt_pass->close();
			return $msg;			
		}
			break;
		default:
			$msg['mode']='1';
			$msg['msg']='[Oneskin]未知情况500';
			return $msg;
			break;
	}
}
    function html_install(){ ?>
    	<div class="am-u-sm-10 am-u-lg-8 am-u-sm-centered" style="margin-top: 10%;">
    		<div class="am-panel am-panel-primary">
    			<div class="am-panel-hd" id="panel_title">第一步</div>
    			<div class="am-panel-bd" id="a1">
    				<table class="am-table am-table-bordered am-table-radius am-table-striped">
    					<thead><tr>
    						<th>运行所需环境</th>
    						<th>是否支持</th>
    					</tr></thead>
    					<tbody>
    					<?php 
    					    $i=0;//变量初始化
    						writefile('test.txt', '2333');
							echo html_table_check('PHP运行环境',2);
							echo html_table_check('Html运行环境',2);
							if(file_exists('test.txt')){
								echo html_table_check('新建文件权限',2);
							}else{
								$i=1+$i;
								echo html_table_check('新建文件权限',1);
							}
							if(rename('test.txt','../test.txt')){
								echo html_table_check('移动文件权限',2);
							}else{
								$i=1+$i;
								echo html_table_check('移动文件权限',1);
							}
							if(unlink('../test.txt')){
								echo html_table_check('删除文件权限',2);
							}else{
								$i=1+$i;
								echo html_table_check('删除文件权限',1);
							}
						?>
    					</tbody>
    				</table>
    				<?php if($i>=1){
    					echo '<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="">你遇到的错误似乎有点多</button>';
    				}else{
    					echo '<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="next(2)">进入下一步</button>';
    				} ?>
    			</div>
    			<!--a1部分-->
    			<div class="am-panel-bd" id="a2" style="display: none;">
    				<blockquote>命运之门已经打开</blockquote>
    				<div id="check_db">
    				<div class="am-input-group">
    					<span class="am-input-group-label">数据库地址</span>
    					<input type="text" class="am-form-field" placeholder="127.0.0.1" id="db_host">
    				</div><br>
    				<div class="am-input-group">
    					<span class="am-input-group-label">数据库端口</span>
    					<input type="text" class="am-form-field" placeholder="3306" id='db_port'>
    				</div><br>
    				<div class="am-input-group">
    					<span class="am-input-group-label">数据库账号</span>
    					<input type="text" class="am-form-field" placeholder="Username" id="db_username">
    				</div><br>
    				<div class="am-input-group">
    					<span class="am-input-group-label">数据库密码</span>
    					<input type="password" class="am-form-field" placeholder="Password" id="db_password">
    				</div><br>
    				<div class="am-input-group">
    					<span class="am-input-group-label">数据库库名</span>
    					<input type="text" class="am-form-field" placeholder="Test" id="db_name">
    				</div><br>
    				<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="check_db()">测试连接</button>
    				</div>
    				<div id="select_div" style="display: none;">
    					<select data-am-selected="{btnStyle: 'primary',searchBox: 1,btnWidth: '100%'}" id="select_mode">
    						<optgroup label="兼容模式">
    							<option value="None">使用自带数据库结构</option>
    							<option value="Beelogin">使用Beelogin数据库结构</option>
    							<option value="Authme">使用Authme数据库结构</option>
    						</optgroup>
    					</select>    					
    				</div><br>	
    				<div id="Beelogin" style="display: none;">
    					<div class="am-input-group">
    						<span class="am-input-group-label">Beelogin表名</span>
    						<input type="text" class="am-form-field" placeholder="beelogin" id="db_beelogin_table">
    					</div><br>
    					<div class="am-input-group">
    						<span class="am-input-group-label">用户名列列名</span>
    						<input type="text" class="am-form-field" placeholder="user" id="db_beelogin_username">
    					</div><br>
    					<div class="am-input-group">
    						<span class="am-input-group-label">密码列列名</span>
    						<input type="text" class="am-form-field" placeholder="pass" id="db_beelogin_password">
    					</div><br>
    					<div class="am-input-group">
    						<span class="am-input-group-label">密码散列列名</span>
    						<input type="text" class="am-form-field" placeholder="salt" id="db_beelogin_password_salt">
    					</div><br>    						      						    						
    				</div>
    				<div id="Authme" style="display: none;">
    					<div class="am-input-group">
    						<span class="am-input-group-label">Authme表名</span>
    						<input type="text" class="am-form-field" placeholder="authme" id="db_authme_table">
    					</div><br>
    					<div class="am-input-group">
    						<span class="am-input-group-label">用户名列列名</span>
    						<input type="text" class="am-form-field" placeholder="username" id="db_authme_username">
    					</div><br>
    					<div class="am-input-group">
    						<span class="am-input-group-label">密码列列名</span>
    						<input type="text" class="am-form-field" placeholder="password" id="db_authme_passworld">
    					</div><br>
    					<div class="am-input-group">
    						<span class="am-input-group-label">真实用户名列名</span>
    						<input type="text" class="am-form-field" placeholder="realname" id="db_authme_realname">
    					</div><br>    						      						    						
    				</div>
    				<br><button type="button" class="am-btn am-btn-primary am-btn-block" style="display: none;" id="next_3" onclick="next(3)">下一步</button>
    			</div>
    			<!--a2部分-->
    			<div id="a3" class="am-panel-bd" style="display: none;">
    				<div class="am-input-group">
    					<span class="am-input-group-label">管理员用户名</span>
    					<input type="text" class="am-form-field" placeholder="请填写管理员用户名" id="admin_username">
    				</div><br>  
    				<div class="am-input-group">
    					<span class="am-input-group-label">管理员密码</span>
    					<input type="password" class="am-form-field" placeholder="请填写管理员密码   不推荐使用弱密码" id="admin_password">
    				</div><br>  
    				<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="next(4)" id="install">下一步</button>  				
    			</div>
    			<!--a3部分-->
    			<div id="a4" class="am-panel-bd" style="display: none;">
    				<blockquote>安装过程中似乎返回了某些信息</blockquote>
    				<p id="msg"></p>
    				<button type="button" class="am-btn am-btn-primary am-btn-block" id="end"></button>
    		    </div>
    		    <!--a4部分-->
    		</div>
    	</div>
<?php
    }
	function html_table_check($var,$mode){ 
		if($mode==1){
			$new='<tr class="am-warning"><td>'.$var.'</td><td>不支持</td></tr>';
		}
		if($mode==2){
			$new='<tr class="am-success"><td>'.$var.'</td><td>支持</td></tr>';
		}
		return $new;
	}
	function writefile($fname,$str){ //写出文件接口
		$fp=fopen($fname,"w");
		fputs($fp,$str);
		fclose($fp);
	}
	function config_read(){//读取config
		include_once('skin_config.php');
		return (array)json_decode(base64_decode($sql_config));
	}
    function getRandChar($length){//生成随机字符串
        $str = null;
        $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
        $max = strlen($strPol)-1;
        for($i=0;$i<$length;$i++){
           $str.=$strPol[rand(0,$max)];//rand($min,$max)生成介于min和max两个数之间的一个随机整数
        }
        return $str;
    }
	function send_email($send_email,$if_ssl,$smtp_host,$smtp_port,$smtp_username,$smtp_password,$email_title,$email_body){//发送邮件
		include('skin_user/skin_email.php');//载入文件
		include('skin_user/skin_smtp.php');//载入文件
        $mail= new PHPMailer(); //new一个PHPMailer对象出来
        $body= eregi_replace("[\]",'',$email_body); //对邮件内容进行必要的过滤
        $mail->CharSet ="utf-8";//设定邮件编码，默认ISO-8859-1，如果发中文此项必须设置，否则乱码
        $mail->IsSMTP(); // 设定使用SMTP服务
        $mail->SMTPDebug  = FALSE;                     // 启用SMTP调试功能
        $mail->SMTPAuth   = TRUE;                  // 启用 SMTP 验证功能
	    if($if_ssl){
		   $mail->SMTPSecure = "ssl";                 // 安全协议，可以注释掉
	    }
        $mail->Port= $smtp_port;                   // SMTP服务器的端口号
        $mail->Host = $smtp_host;
        $mail->Username = $smtp_username;          //发送者用户名
        $mail->Password = $smtp_password;                //发送者密码
        $mail->SetFrom($smtp_username,$email_title);
        $mail->AddReplyTo($smtp_username,$email_title);
        $mail->Subject = $email_title;//邮件标题
        $mail->MsgHTML($body);//邮件内容
        $address = $send_email;
        $mail->AddAddress($address, '');
		if(!$mail->Send()){
			return FALSE;//发送失败返回false
		}else{
			return TRUE;//发送成功发挥true
		}
	}
function array_iconv($data,  $output = 'utf-8') {  
    $encode_arr = array('UTF-8','ASCII','GBK','GB2312','BIG5','JIS','eucjp-win','sjis-win','EUC-JP');  
    $encoded = mb_detect_encoding($data, $encode_arr);  
  
    if (!is_array($data)) {  
        return mb_convert_encoding($data, $output, $encoded);  
    }  
    else {  
        foreach ($data as $key=>$val) {  
            $key = array_iconv($key, $output);  
            if(is_array($val)) {  
                $data[$key] = array_iconv($val, $output);  
            } else {  
            $data[$key] = mb_convert_encoding($data, $output, $encoded);  
            }  
        }  
    return $data;  
    }  
} 
	function html_email($username,$server_name,$url){
		$a='
<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td style="padding: 10px 0 30px 0;">
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border: 1px solid #cccccc; border-collapse: collapse;">
				<tr>
					<td align="center" bgcolor="#70bbd9" style="padding: 40px 0 30px 0; color: #ecf0f1; font-size: 28px; font-weight: bold; font-family: '."'microsoft yahei'".', sans-serif;">
						<h1>
							'.$server_name.'
						</h1>
					</td>
				</tr>
				<tr>
					<td bgcolor="#ffffff" style="padding: 40px 30px 40px 30px;">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="color: #153643; font-family: Arial, sans-serif; font-size: 24px;">
									<b>本邮件有效30分钟</b>
								</td>
							</tr>
							<tr>
								<td style="padding: 20px 0 30px 0; color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 20px;">
									<p>
										欢迎'.$username.'注册'.$server_name.',现在你只需要点击
										<a href="'.$url.'">
											这个
										</a>即可通过邮箱验证。
									</p>
								</td>
							</tr>
							<tr>
								<td style="padding: 20px 0 30px 0; color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 20px;">
									<p>
										如果上方链接无效请手动复制一下链接并访问
										<br>
										'.$url.'
									</p>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td bgcolor="#ee4c50" style="padding: 30px 30px 30px 30px;">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;" width="75%">
									&reg; Fleey&nbsp;Oneskin 2013
									<br/>
									<a href="http://fleey.org" style="color: #ffffff;">
										<font color="#ffffff">访问官网</font>
									</a>进行观摩Fleey的作品
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>';
    return array_iconv($a);
    }
    function html_error($error_number,$error_contain){?>
    	<div id="error" class="am-g am-g-fixed">
    		<div class="am-u-md-8 am-u-sm-centered" style="margin-top: 10%;margin-bottom: 10%;">
    			<h1 style="color: #3498db;text-align: center;" class="am-text-xxxl"><?php echo $error_number; ?></h1>
    			<hr>
    			<p style="color: #95a5a6;text-align: center;" class="am-text-xl"><?php echo $error_contain; ?></p>
    		</div>
    	</div>
<?php    	
    }
	function get_dirname(){
		return dirname('http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"]);
	}
    function get_mysqli_config($mysqli,$config_id){//获取config表内数据
    	$sql_1='select config_contain from skin_config where config_id=?';//sql语句
    	$stmt_1=mysqli_prepare($mysqli, $sql_1);//置入指令
    	mysqli_stmt_bind_param($stmt_1, 's',$config_id);//置入参数
    	mysqli_stmt_bind_result($stmt_1, $config_contain);//获取变量
    	mysqli_stmt_execute($stmt_1);//执行命令
		mysqli_stmt_fetch($stmt_1);//实例化变量
		mysqli_stmt_close($stmt_1);//释放句柄
		if(empty($config_contain)){
			$sql_3='INSERT INTO skin_config (config_id,config_contain) VALUES (?,?)';//sql语句
			$stmt_3=mysqli_prepare($mysqli, $sql_3);//置入指令
			mysqli_stmt_bind_param($stmt_3, "ss", $config_id, $str1);
			$str1='';
			mysqli_stmt_execute($stmt_3);
			mysqli_stmt_close($stmt_3);//释放句柄
		}
		return $config_contain;//返回数据
    }
	function update_mysqli_config($mysqli,$config_id,$config_contain){
		$sql_4="UPDATE skin_config SET config_contain=? where config_id=?";
		$stmt_4 = mysqli_prepare($mysqli, $sql_4);
		mysqli_stmt_bind_param($stmt_4, "ss",$config_contain,$config_id);//sql预处理交互
		$a=mysqli_stmt_execute($stmt_4);
		mysqli_stmt_close($stmt_4);//释放句柄	
		return $a;
	}
	function object_array($array) {
		  if(is_object($array)) {
		  	  $array = (array)$array;  
		  } if(is_array($array)) {
		  	  foreach($array as $key=>$value) {
		  	  	  $array[$key] = object_array($value);  
			  }  
		  }  
		  return $array;  
	}
	function html_admin_config($info_sql,$mysqli){
		$smtp_config=get_mysqli_config($mysqli,'smtp_config');
		if(!empty($smtp_config)){
			$smtp_config=json_decode($smtp_config);
			$smtp_config=object_array($smtp_config);
			if($smtp_config['smtp_ssl']=='yes'){
				$a='selected="selected"';
			}else{
				$b='selected="selected"';
			}
		}
	?>
<div id="admin_config">
	<div class="am-cf am-padding">
		<div class="am-fl am-cf">
			<strong class="am-text-primary am-text-lg" id="info_title">Config</strong> / <small id="info_title_small">配置你的皮肤站</small>
		</div><br><hr>
	</div>
	<div class="am-g">
		<div class="am-u-sm-centered am-u-md-9">
			<div class="am-panel am-panel-primary">
				<div class="am-panel-hd">
					Mysql数据库
				</div>
				<div class="am-panel-bd">
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">数据库地址&nbsp;&nbsp;&nbsp;&nbsp;</span>
						<input type="text" class="am-form-field" placeholder="数据库地址 127.0.0.1" id="db_host" value="<?php echo $info_sql['db_host']; ?>">
					</div>
					<br>
					<!--数据库地址-->
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">数据库端口&nbsp;&nbsp;&nbsp;&nbsp;</span>
						<input type="text" class="am-form-field" placeholder="数据库端口 3306" id="db_port" value="<?php echo $info_sql['db_port']; ?>">
					</div>
					<br>
					<!--数据库端口-->
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">数据库用户名</span>
						<input type="text" class="am-form-field" placeholder="数据库用户名 Username" id="db_username" value="<?php echo $info_sql['db_username']; ?>">
					</div>
					<br>
					<!--数据库用户名-->
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">数据库密码&nbsp;&nbsp;&nbsp;</span>
						<input type="text" class="am-form-field" placeholder="数据库密码 Password" id="db_password" value="<?php echo $info_sql['db_password']; ?>">
					</div>
					<br>
					<!--数据库密码-->
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">主数据库&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
						<input type="text" class="am-form-field" placeholder="主数据库 Test" id="db_name" value="<?php echo $info_sql['db_name'] ;?>">
					</div>
					<br>
					<!--主数据库-->
					<button type="button" class="am-btn am-btn-primary am-btn-block  btn-loading-example" data-am-loading="{spinner: 'circle-o-notch'}" id="save_config_db" onclick="save_config_db()">保存</button>
				</div>
			</div>
			<!--数据库框架-->
			<div class="am-panel am-panel-primary">
				<div class="am-panel-hd">
					找回密码邮箱服务
				</div>		
				<div class="am-panel-bd">
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">Smtp_Host</span>
						<input type="text" class="am-form-field" id="smtp_host" placeholder="Smtp服务器地址" value="<?php echo @$smtp_config['smtp_host']; ?>">
					</div><br>
					<!--smtp_Host-->
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">Smtp_Port</span>
						<input type="text" class="am-form-field" id="smtp_port" placeholder="Smtp服务器端口" value="<?php echo @$smtp_config['smtp_port']; ?>">
					</div><br>
					<!--smtp_Port-->	
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">Smtp_Username</span>
						<input type="text" class="am-form-field" id="smtp_username" placeholder="Smtp用户名" value="<?php echo @$smtp_config['smtp_username']; ?>">
					</div><br>
					<!--smtp_Username-->	
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">Smtp_Password</span>
						<input type="text" class="am-form-field" id="smtp_password" placeholder="Smtp密码"  value="<?php echo @$smtp_config['smtp_password']; ?>">
					</div><br>
					<!--smtp_Password-->	
    				<div id="select_div">
    					<select id="smtp_mode" style="width: 100%;">
    						<option value="yes" <?php echo @$a; ?>>支持SSL</option>
    						<option value="no" <?php echo @$b; ?>>不支持SSL</option>
    					</select>    					
    				</div><br>		
    				<!--是否支持SSL-->		
    				<?php if(empty($smtp_config)){ ?>
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">获取验证邮件</span>
						<input type="email" class="am-form-field" id="smtp_send_code" placeholder="获取验证码邮箱">
					</div><br>	
					<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="smtp_get_code()" id="smtp_get_code">获取</button>	    					
    			<?php }else{ ?>
    				<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="smtp_config_save()" id="smtp_get_code">保存</button>	    		
    			<?php } ?>									
				</div>		
			</div>
			<!--邮箱绑定框架-->
			<div class="am-panel am-panel-primary">
				<div class="am-panel-hd">
					设置皮肤站名
				</div>		
				<div class="am-panel-bd">
					<div class="am-input-group am-input-group-sm">
						<span class="am-input-group-label">皮肤站名</span>
						<input type="text" class="am-form-field" id="title_name" placeholder="皮肤站名" value="<?php echo @$info_sql['title']; ?>">
					</div><br>	
    				<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="title_config_save()" id="smtp_get_code">保存</button>	    										
				</div>		
			</div>			
			<!--设置服务器名框架-->
		</div>
	</div>
</div>
<?php		
	}
//过滤文档
  function cleanAll($html){//总体调用
  	return cleanYellow(cleanJsCss(cleanJs(setFilter($html))));
  }
  function cleanJs($html){//过滤js部分
  	$html=trim($html);
  	$html=str_replace(array('<?','?>'),array('<?','?>'),$html);
  	$pattern=array(
    "'<script[^>]*?>.*?</script>'si",
    "'<style[^>]*?>.*?</style>'si",
    "'<frame[^>]*?>'si",
    "'<iframe[^>]*?>.*?</iframe>'si",
    "'<link[^>]*?>'si"
    );
    $replace=array("","","","","");
    return	preg_replace($pattern,$replace,$html);
  }
  function cleanJsCss($html){//过滤css部分
  	$html=trim($html);
  	$html=preg_replace('/\0+/', '', $html);
	$html=preg_replace('/(\\\\0)+/', '', $html);
	$html=preg_replace('#(&\#*\w+)[\x00-\x20]+;#u',"\\1;",$html);
	$html=preg_replace('#(&\#x*)([0-9A-F]+);*#iu',"\\1\\2;",$html);
	$html=preg_replace("/%u0([a-z0-9]{3})/i", "&#x\\1;", $html);
	$html=preg_replace("/%([a-z0-9]{2})/i", "&#x\\1;", $html);
  	$html=str_replace(array('<?','?>'),array('<?','?>'),$html);
    $html=preg_replace('#\t+#',' ',$html);
	$scripts=array('javascript','vbscript','script','applet','alert','document','write','cookie','window');
	foreach($scripts as $script){
		$temp_str="";
		for($i=0;$i<strlen($script);$i++){
			$temp_str.=substr($script,$i,1)."\s*";
		}
		$temp_str=substr($temp_str,0,-3);
		$html=preg_replace('#'.$temp_str.'#s',$script,$html);
		$html=preg_replace('#'.ucfirst($temp_str).'#s',ucfirst($script),$html);
	}
	$html=preg_replace("#<a.+?href=.*?(alert\(|alert&\#40;|javascript\:|window\.|document\.|\.cookie|<script|<xss).*?\>.*?</a>#si", "", $html);
	$html=preg_replace("#<img.+?src=.*?(alert\(|alert&\#40;|javascript\:|window\.|document\.|\.cookie|<script|<xss).*?\>#si", "", $html);
	$html=preg_replace("#<meta.+.*?\>#si", "", $html);//处理该死的meta头
	$html=preg_replace("#<(script|xss).*?\>#si", "<\\1>", $html);
	$html=preg_replace('#(<[^>]*?)(onblur|onchange|onclick|onfocus|onload|onmouseover|onmouseup|onmousedown|onselect|onsubmit|onunload|onkeypress|onkeydown|onkeyup|onresize)[^>]*>#is',"\\1>",$html);
	//$html=preg_replace('#<(/*\s*)(alert|applet|basefont|base|behavior|bgsound|blink|body|embed|expression|form|frameset|frame|head|html|ilayer|iframe|input|layer|link|meta|object|plaintext|style|script|textarea|title|xml|xss)([^>]*)>#is', "<\\1\\2\\3>", $html);
	$html=preg_replace('#<(/*\s*)(alert|applet|basefont|base|behavior|bgsound|blink|body|expression|form|frameset|frame|head|html|ilayer|iframe|input|layer|link|meta|object|plaintext|style|script|textarea|title|xml|xss)([^>]*)>#is', "<\\1\\2\\3>", $html);
	$html=preg_replace('#(alert|cmd|passthru|eval|exec|system|fopen|fsockopen|file|file_get_contents|readfile|unlink)(\s*)\((.*?)\)#si', "\\1\\2(\\3)", $html);
	$bad=array(
	'document.cookie'	=> '',
	'document.write'	=> '',
	'window.location'	=> '',
	"javascript\s*:"	=> '',
	"Redirect\s+302"	=> '',
	'<!--'				=> '<!--',
	'-->'				=> '-->'
	);
	foreach ($bad as $key=>$val){
		$html=preg_replace("#".$key."#i",$val,$html);
	}
    return	$html;
  }
function cleanYellow($txt){//过滤色情等字符
  	$txt=str_replace(
  	array("黄色","性爱","做爱","我日","我草","我靠","尻","共产党","胡锦涛","毛泽东",
  	"政府","中央","研究生考试","性生活","色情","情色","我考","麻痹","妈的","阴道",
  	"淫","奸","阴部","爱液","阴液","臀","色诱","煞笔","傻比","阴茎","法轮功","性交","阴毛","江泽民"),
  	array("*","*","*","*","*","*","*","*","*","*",
  	"*","*","*","*","*","*","*","*","*","*",
  	"*","*","*","*","*","*","*","*","*","*","*","*","*","*"),
  	$txt);
  	return $txt;
 }
  function setFilter($html){//全角字符替换
  		$arr=array('０' => '0', '１' => '1', '２' => '2', '３' => '3', '４' => '4',
                 '５' => '5', '６' => '6', '７' => '7', '８' => '8', '９' => '9',
                 'Ａ' => 'A', 'Ｂ' => 'B', 'Ｃ' => 'C', 'Ｄ' => 'D', 'Ｅ' => 'E',
                 'Ｆ' => 'F', 'Ｇ' => 'G', 'Ｈ' => 'H', 'Ｉ' => 'I', 'Ｊ' => 'J',
                 'Ｋ' => 'K', 'Ｌ' => 'L', 'Ｍ' => 'M', 'Ｎ' => 'N', 'Ｏ' => 'O',
                 'Ｐ' => 'P', 'Ｑ' => 'Q', 'Ｒ' => 'R', 'Ｓ' => 'S', 'Ｔ' => 'T',
                 'Ｕ' => 'U', 'Ｖ' => 'V', 'Ｗ' => 'W', 'Ｘ' => 'X', 'Ｙ' => 'Y',
                 'Ｚ' => 'Z', 'ａ' => 'a', 'ｂ' => 'b', 'ｃ' => 'c', 'ｄ' => 'd',
                 'ｅ' => 'e', 'ｆ' => 'f', 'ｇ' => 'g', 'ｈ' => 'h', 'ｉ' => 'i',
                 'ｊ' => 'j', 'ｋ' => 'k', 'ｌ' => 'l', 'ｍ' => 'm', 'ｎ' => 'n',
                 'ｏ' => 'o', 'ｐ' => 'p', 'ｑ' => 'q', 'ｒ' => 'r', 'ｓ' => 's',
                 'ｔ' => 't', 'ｕ' => 'u', 'ｖ' => 'v', 'ｗ' => 'w', 'ｘ' => 'x',
                 'ｙ' => 'y', 'ｚ' => 'z',
                 '（' => '(', '）' => ')', '〔' => '[', '〕' => ']', '【' => '[',
                 '】' => ']', '〖' => '[', '〗' => ']', '“' => '[', '”' => ']',
                 '‘' => '[', '’' => ']', '｛' => '{', '｝' => '}', '《' => '<',
                 '》' => '>',
                 '％' => '%', '＋' => '+', '—' => '-', '－' => '-', '～' => '-',
                 '：' => ':', '。' => '.', '、' => ',', '，' => '.', '、' => '.',
                 '；' => ',', '？' => '?', '！' => '!', '…' => '-', '‖' => '|',
                 '”' => '"', '’' => '`', '‘' => '`', '｜' => '|', '〃' => '"',
                 '　' => ' ');
    	return	strtr($html,$arr);
  }
function html_admin_index($mysqli,$info_config){
		$skin_list = mysqli_num_rows(mysqli_query($mysqli,"SELECT id FROM skinlink;"));
		$ape_list = mysqli_num_rows(mysqli_query($mysqli,"SELECT id FROM apelink;"));
		$find_pass = mysqli_num_rows(mysqli_query($mysqli,"SELECT user FROM skin_email;"));
		if($info_config['mode']=='beelogin' or $info_config['mode']=='authme'){
			$user_list = mysqli_num_rows(mysqli_query($mysqli,"SELECT ".$info_config['username']." FROM ".$info_config['table'].";"));
		}else{
			$user_list = mysqli_num_rows(mysqli_query($mysqli,"SELECT user FROM skinme;"));
		}
?>
      <div class="am-cf am-padding">
        <div class="am-fl am-cf"><strong class="am-text-primary am-text-lg" id="info_title">首页</strong> / <small id="info_title_small">一些有用的信息</small></div>
      </div>
      <ul class="am-avg-sm-1 am-avg-md-4 am-margin am-padding am-text-center admin-content-list ">
        <li><a href="#" class="am-text-success"><span class="am-icon-btn am-icon-file-text"></span><br/>已有存放皮肤<br/><?php echo $skin_list;?></a></li>
        <li><a href="#" class="am-text-success"><span class="am-icon-btn am-icon-file-text"></span><br/>已有存放披风<br/><?php echo $ape_list;?></a></li>
        <li><a href="#" class="am-text-danger"><span class="am-icon-btn am-icon-recycle"></span><br/>忘记密码玩家数量<br/><?php echo $find_pass;?></a></li>
        <li><a href="#" class="am-text-secondary"><span class="am-icon-btn am-icon-user-md"></span><br/>当前用户数量<br/><?php echo $user_list;?></a></li>
      </ul>
<?php	
}
function html_admin_change_password(){ ?>
<div id="admin_config">
	<div class="am-cf am-padding">
		<div class="am-fl am-cf">
			<strong class="am-text-primary am-text-lg" id="info_title">Change_Admin_Pass</strong> / <small id="info_title_small">让你的密码更加安全</small>
		</div><br><hr>
	</div>
	<div class="am-g">
		<div class="am-u-sm-centered am-u-md-9">
			<div class="am-panel am-panel-primary">
				<div class="am-panel-hd">
					修改密码
				</div>
				<div class="am-panel-bd">
					<div class="am-input-group">
						<span class="am-input-group-label">管理员旧密码</span>
						<input type="text" class="am-form-field" placeholder="管理员旧密码" id="old_admin_password">
					</div><br>
					<div class="am-input-group">
						<span class="am-input-group-label">管理员新密码</span>
						<input type="text" class="am-form-field" placeholder="管理员新密码" id="new_admin_password">
					</div><br>
					<div class="am-input-group">
						<span class="am-input-group-label">管理员新密码</span>
						<input type="text" class="am-form-field" placeholder="再来一次新密码" id="again_new_admin_password">
					</div><br>				
					<button type="button" class="am-btn am-btn-primary am-btn-block" onclick="change_password()">修改</button>		
				</div>
			</div>
		</div>
	</div>
</div>
<?php	
}
function html_player_list($mysqli,$info_config){
	if($info_config['mode']=='none'){
		$sql='select user from skinme';
	}
	if($info_config['mode']=='authme'){
		$sql='select '.$info_config['realname'].' from '.$info_config['table'];
	}
	if($info_config['mode']=='beelogin'){
		$sql='select '.$info_config['username'].' from '.$info_config['table'];
	}
	$stmt_1 = mysqli_prepare($mysqli, $sql);//代入代码
	mysqli_stmt_execute($stmt_1);
	mysqli_stmt_bind_result($stmt_1,$username);
?>
<div id="admin_config">
	<div class="am-cf am-padding">
		<div class="am-fl am-cf">
			<strong class="am-text-primary am-text-lg" id="info_title">玩家列表</strong> / <small id="info_title_small">更好的管理玩家</small>
		</div><br><hr>
	</div>
	<div class="am-g">
		<div class="am-u-sm-centered am-u-md-9">
			<div class="am-panel am-panel-primary">
				<div class="am-panel-hd">
					玩家列表
				</div>
				<div class="am-panel-bd">
					<table class="am-table am-table-striped am-table-hover">
						<thead>
							<tr>
								<th>玩家名</th>
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
								<?php
								 while(mysqli_stmt_fetch($stmt_1)){
								 	echo '<tr id=\''.$username.'\'><td>'.$username.'</td><td><button type="button" class="am-btn am-btn-primary" onclick="user_info(\''.$username.'\')">修改密码</button><button type="button" class="am-btn am-btn-warning" onclick="del_user(\''.$username.'\')">删除用户</button></td></tr>';
								 }
								 mysqli_stmt_close($stmt_1);//释放句柄
								 ?>
						</tbody>
					</table>	
				</div>
			</div>
		</div>
	</div>
</div>	
<?php	
}
?>