<?php
include('basis_html.php');
if(!file_exists('skin_config.php')){
	exit(header("Location: skin_admin/skin_install.php")); 
}
$act=$_GET['act'];
switch ($act) {
	case 'login':
		$a='am-active';
		$b='';
		$c='';
		break;
	case 'register':
		$b='am-active';
		$a='';
		$c='';		
		break;
	case 'find_password':
		$c='am-active';
		$b='';
		$a='';
		break;		
	default:
		$a='am-active';
		$b='';
		$c='';		
		break;
}
?>
<!DOCTYPE html>
<html class="no-js fixed-layout">
	<head>
		<title><?php
		$info_sql=config_read();//读入配置 
		if(empty($info_sql['title'])){
			echo 'Oneskin';
		}else{
			echo $info_sql['title'];
		}
		 ?></title>
		<?php html_css(); ?>
	</head>
	<body>
		<div class="am-u-sm-12 am-u-lg-7 am-u-sm-centered" style="margin-top: 9%;">
			<div class="am-panel am-panel-default am-animation-scale-up" style="box-shadow:2px 2px 5px #909090;">
				<div class="am-panel-bd">
					<p><?php if(empty($info_sql['title'])){ echo 'Oneskin';}else{ echo $info_sql['title'];}?>皮肤站</p>
					<div class="am-tabs" data-am-tabs="{noSwipe: 1}" id="pane_body">
						<ul class="am-tabs-nav am-nav am-nav-tabs">
							<li class="<?php echo $a; ?>" ><a href="#login">登录</a></li>
							<li class="<?php echo $b; ?>" ><a href="#register">注册</a></li>
							<li class="<?php echo $c; ?>" ><a href="#find_password">找回密码</a></li>
						</ul>
						<div class="am-tabs-bd">
							<div class="am-tab-panel <?php echo $a; ?>" id="login">
								<div class="am-input-group">
									<span class="am-input-group-label">用户名</span>
									<input type="text" class="am-form-field" id="login_username" placeholder="你的登录用户名">
								</div><br>
									<!--用户名框架-->
								<div class="am-input-group">
									<span class="am-input-group-label">密&nbsp;&nbsp;&nbsp;&nbsp;码</span>
									<input type="password" class="am-form-field" id="login_password" placeholder="你的登录密码">
								</div><br>
									<!--密码框架-->
								<div class="am-cf" style="display: none;" id="code">
									<div class="am-input-group am-fl" style="width: 75%;">
										<span class="am-input-group-label">验证码</span>
										<input type="text" class="am-form-field" id="login_code" placeholder="输入右边的验证码">
									</div>
									<div class="am-fr" style="width: 22%;">
										<img class="am-thumbnail" src="skin_code.php" alt="" onclick="newcode()" id="img_code_1" style="width: 100%;height: 40px;" />   
									</div>
								</div>
								<!--验证码框架-->	
				<button type="submit" class="am-btn am-btn-primary am-btn-block  btn-loading-example" data-am-loading="{spinner: 'circle-o-notch'}" id="ajax_login" onclick="login()">
					登录
				</button>			
							</div>
							<!--登录框架结束-->
							<div class="am-tab-panel <?php echo $b; ?>" id="register">
								<div class="am-input-group">
									<span class="am-input-group-label">用户名</span>
									<input type="text" class="am-form-field" id="register_username" placeholder="你的游戏用户名" required/>
									<span class="am-input-group-btn"><button class="am-btn am-btn-primary" onclick="check_username()" type="button">检测用户名</button></span>	
								</div><br>		
								<!--用户名-->
								<div class="am-input-group">
									<span class="am-input-group-label">密&nbsp;&nbsp;&nbsp;&nbsp;码</span>
									<input type="password" class="am-form-field" id="register_password" placeholder="你的登录密码" required/>
								</div><br>
								<!--登录密码-->	
								<div class="am-input-group">
									<span class="am-input-group-label">邮&nbsp;&nbsp;&nbsp;&nbsp;箱</span>
									<input type="email" class="am-form-field" id="register_email" placeholder="你的邮箱地址" required/>
								</div><br>	
									<!--邮箱框架-->								
								<div class="am-cf">
									<div class="am-input-group am-fl" style="width: 75%;">
										<span class="am-input-group-label">验证码</span>
										<input type="text" class="am-form-field" id="register_code" placeholder="输入右边的验证码  获取邮件" required/>
									</div>
									<div class="am-fr" style="width: 22%;">
										<img class="am-thumbnail" src="skin_code.php" alt="" onclick="newcode()" id="img_code_2" style="width: 100%;height: 40px;" />   
									</div>
								</div>
								<!--验证码框架-->		
								<button type="submit" class="am-btn am-btn-primary am-btn-block btn-loading-example"  id="register_button" data-am-loading="{loadingText: '努力加载中...'}" onclick="register()">注册</button>																						
							</div>	
							<!--注册框架结束-->
							<div class="am-tab-panel <?php echo $c; ?>" id="find_password">
								<blockquote>目前仅仅提供邮箱找回密码</blockquote>
								<div class="am-input-group">
									<span class="am-input-group-label">用户名</span>
									<input type="text" class="am-form-field" id="find_password_username" placeholder="你的游戏用户名" required/>
								</div><br>		
								<!--用户名-->	
								<div class="am-input-group">
									<span class="am-input-group-label">邮&nbsp;&nbsp;&nbsp;&nbsp;箱</span>
									<input type="email" class="am-form-field" id="find_password_email" placeholder="你的邮箱地址" required/>
								</div><br>	
								<!--邮箱框架-->		
								<div class="am-cf">
									<div class="am-input-group am-fl" style="width: 75%;">
										<span class="am-input-group-label">验证码</span>
										<input type="text" class="am-form-field" id="find_password_code" placeholder="输入右边的验证码">
									</div>
									<div class="am-fr" style="width: 22%;">
										<img class="am-thumbnail" src="skin_code.php" alt="" onclick="newcode()" id="img_code_3" style="width: 100%;height: 40px;" />   
									</div>
								</div>
								<!--验证码框架-->
								<button type="submit" class="am-btn am-btn-primary am-btn-block btn-loading-example" id="find_password_button" data-am-loading="{loadingText: '努力加载中...'}" onclick="send_email()">找回</button>																
							</div>			
							<!--找回密码框架结束-->			
						</div>
					</div>
					<!--选项框部分-->
				</div>
			</div>
			<!--面板部分-->
		</div>
		<!--内容部分-->
		<!--背景部分-->
		<div style="position:absolute; width:100%; height:100%; z-index:-1; left:0; top:0;">      
            <img src="images/bg[1].jpg" height="100%" width="100%" style="left:0; top:0;">   
        </div>
		<!--footer-->
		<div class="href">
		© <a href="#">Bee Studio</a> 2016
		</div>
		<?php html_js(); ?>
		<script type="text/javascript" src="js/toaster.js" ></script>
		<script type="text/javascript" src="js/index.js" ></script>
	</body>
</html>