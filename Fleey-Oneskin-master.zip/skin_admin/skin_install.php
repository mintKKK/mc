<?php
include('../basis_html.php');//载入html
if(file_exists('../skin_config.php')){
	exit(header("Location: ../index.php")); 
}
?>
<!doctype html>
<html class="no-js">
	<head>
		<?php html_inside_css(); ?>
		<style type="text/css">
			*{ padding: 0; margin: 0; }
			html{ overflow-y: scroll; }
			body{ background: #fff; font-family: '微软雅黑'; color: #333; font-size: 16px; }
			img{ border: 0; }
			.error{ padding: 24px 48px; }
			.face{ font-size: 100px; font-weight: normal; line-height: 120px; margin-bottom: 12px; }
			h1{ font-size: 32px; line-height: 48px; }
			.error .content{ padding-top: 10px}
			.error .info{ margin-bottom: 12px; }
			.error .info .title{ margin-bottom: 3px; }
			.error .info .title h3{ color: #000; font-weight: 700; font-size: 16px; }
			.error .info .text{ line-height: 24px; }
			.copyright{ padding: 12px 48px; color: #999; }
			.copyright a{ color: #000; text-decoration: none; }
		</style>
	</head>
	<body style="background-image: url(../images/bg[2].png);">
		<?php if(FALSE){ ?>
			<div class="error">
				<p class="face">:(</p>
				<h1>页面错误！请稍后再试～</h1>
				<div class="content"></div>
			</div>
			<div class="copyright">
				<p><h3>错误详情：</h3></p>
				<p>你貌似没有开启PHP运行环境</p>
			<p><blockquote>处理办法如下</blockquote></p>
			<p>1.下载<a href="http://rj.baidu.com/soft/detail/12489.html?ald">XAMPP</a>运行环境。</p>
			<p>2.下载<a href="http://rj.baidu.com/soft/detail/17836.html?ald">PHPStudy</a>运行环境。</p>
			<p>3.下载<a href="#">IIS</a>运行环境。</p>
			</div>
		<?php }else{ html_install(); } ?>
		<?php html_inside_js(); ?>
		<script type="text/javascript" src="../js/skin_install.js" ></script>
		<script type="text/javascript" src="../js/toaster.js" ></script>
	</body>
</html>	