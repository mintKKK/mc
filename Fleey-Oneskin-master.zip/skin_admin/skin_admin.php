<?php
include('../basis_html.php');
session_start();
$act=$_REQUEST['act'];
$check_code=strtolower($_SESSION['check']);
$info_sql=config_read();
$groups=$_REQUEST['groups'];
if(empty($act)){
	exit(json_encode(array('msg'=>'你貌似不在状态!','mode'=>'1')));
}
if($act=='admin_login'){
	if(empty($check_code)){
		exit(json_encode(array('msg'=>'刷新一下验证码吧!','mode'=>'1')));
	}
	$login_username=$_REQUEST['login_username'];//登录账号
	$login_password=$_REQUEST['login_password'];//登录密码
	$login_code=strtolower($_REQUEST['login_code']);//登录验证码
	if(empty($login_code) or empty($login_username) or empty($login_password)){
		exit(json_encode(array('msg'=>'你似乎有东西忘记填写了!','mode'=>'1')));
	}
	if($login_code!=$check_code){
		exit(json_encode(array('msg'=>'你验证码似乎有点不正确!','mode'=>'1')));
	}
	unset($_SESSION['check']);
	if(md5($login_username)!=$info_sql['admin_username']){
		exit(json_encode(array('msg'=>'账号或密码不正确!','mode'=>'1')));
	}
	if(md5($login_password)!=$info_sql['admin_password']){
		exit(json_encode(array('msg'=>'账号或密码不正确!','mode'=>'1')));
	}
	$_SESSION['admin_username']=md5($login_username);
	$_SESSION['admin_password']=md5($login_password);
	exit(json_encode(array('msg'=>'登录成功,两秒后将为你转跳!','mode'=>'2')));
}
$mysqli = mysqli_connect($info_sql['db_host'], $info_sql['db_username'], $info_sql['db_password'], $info_sql['db_name'], $info_sql['db_port']);
if($groups=='admin'){//管理员权限
	if(($_SESSION['admin_username']!=$info_sql['admin_username']) or ($_SESSION['admin_password']!=$info_sql['admin_password'])){//判断权限
		exit(json_encode(array('msg'=>'很抱歉，不能越权操作！','mode'=>'1')));
	}
	if($act=='phpinfo'){
	    exit(phpinfo());
	}
	if($act=='change_password'){
		$old_admin_password=$_REQUEST['old_admin_password'];
		$new_admin_password=$_REQUEST['new_admin_password'];
		$new_again_admin_password=$_REQUEST['new_again_admin_password'];
		if(empty($old_admin_password) or empty($new_admin_password) or empty($new_again_admin_password)){
			exit(json_encode(array('msg'=>'你有东西忘记填写了!','mode'=>'1')));
		}
		if($new_admin_password!=$new_again_admin_password){
			exit(json_encode(array('msg'=>'两次密码不一致!','mode'=>'1')));
		}
		if(md5($old_admin_password)!=$info_sql['admin_password']){
			exit(json_encode(array('msg'=>'管理密码有点不一致!','mode'=>'1')));
		}
		$info_sql['admin_password']=md5($new_admin_password);
		writefile("../skin_config.php", "<?php ".'$sql_config'."='".base64_encode(json_encode($info_sql))."'; ?>");
	    unset($_SESSION['admin_username']);
	    unset($_SESSION['admin_password']);		
		$info['msg']='更改管理员密码成功!';
		$info['mode']='2';
		exit(json_encode($info));
	}
	if($act=='change_user_password'){
		$user_username=$_REQUEST['user_username'];
		$user_password=$_REQUEST['user_password'];
		$user_again_password=$_REQUEST['user_again_password'];
		if(empty($user_username) or empty($user_password) or empty($user_again_password)){
			exit(json_encode(array('msg'=>'你有东西忘记填写了!','mode'=>'1')));
		}
		if($user_again_password!=$user_password){
			exit(json_encode(array('msg'=>'两次密码不一致','mode'=>'1')));
		}
		exit(json_encode(change_password($mysqli, $info_sql, $user_again_password, $user_username)));
	}
	if($act=='del_user'){
		$user_username=$_REQUEST['user_username'];
		if(empty($user_username)){
			exit(json_encode(array('msg'=>'有东西你貌似漏了！','mode'=>'1')));
		}
		if($info_sql['mode']=='none'){
			$sql_11='DELETE FROM skinme where user=?';//sql命令
		}
		if($info_sql['mode']=='authme'){
			$sql_11='DELETE FROM '.$info_sql['table'].' where username=?';//sql命令
		}
		if($info_sql['mode']=='beelogin'){
			$sql_11='DELETE FROM '.$info_sql['table'].' where username=?';//sql命令
		}
		$stmt_11=mysqli_prepare($mysqli, $sql_11);//置入指令
		if(!mysqli_stmt_bind_param($stmt_11, 's',$user_username)){
			exit(json_encode(array('mode'=>'1','msg'=>'信息置入失败?')));
		}
		if(!mysqli_stmt_execute($stmt_11)){
			mysqli_stmt_close($stmt_11);
			exit(json_encode(array('mode'=>'1','msg'=>'删除失败!详细如下:'.mysqli_stmt_error($stmt_11))));
		}
		mysqli_stmt_close($stmt_11);
		exit(json_encode(array('mode'=>'2','msg'=>'删除成功?')));
	}
	if($act=='del_skin'){
		$skin_id = round($_REQUEST['skin_id']);
		$skin_mode=$_REQUEST['mode'];
		if(empty($skin_id) or empty($skin_mode) or ($skin_mode!='ape' and $skin_mode!='skin')){
		exit(json_encode(array('msg' => '貌似有些参数空了','mode' => "1")));		
		}
		if($skin_mode=='skin'){
			$sql_select='select md5 from skinlink where id=?';
			$sql='delete from skinlink where id=?';
		}else{
			$sql_select='select md5 from apelink where id=?';
			$sql='delete from apelink where id=?';
		}
		$stmt_select=mysqli_prepare($mysqli, $sql_select);//置入指令
		if(!mysqli_stmt_bind_param($stmt_select,'s',$skin_id)){
			exit(json_encode(array('mode'=>'1','msg'=>'信息置入失败?'.$sql)));
		}		
		if(!mysqli_stmt_execute($stmt_select)){
			mysqli_stmt_close($stmt_select);
			exit(json_encode(array('mode'=>'1','msg'=>'删除失败!详细如下:'.mysqli_stmt_error($stmt_select))));
		}		
		mysqli_stmt_bind_result($stmt_select,$skin_md5);
		mysqli_stmt_fetch($stmt_select);
		mysqli_stmt_close($stmt_select);
		if(empty($skin_md5)){
			exit(json_encode(array('mode'=>'1','msg'=>'错误没有找到这个皮肤或披风')));
		}
		$stmt_11=mysqli_prepare($mysqli, $sql);//置入指令
		if(!mysqli_stmt_bind_param($stmt_11,'i',$skin_id)){
			exit(json_encode(array('mode'=>'1','msg'=>'信息置入失败?'.$sql)));
		}
		if(!mysqli_stmt_execute($stmt_11)){
			mysqli_stmt_close($stmt_11);
			exit(json_encode(array('mode'=>'1','msg'=>'删除失败!详细如下:'.mysqli_stmt_error($stmt_11))));
		}
		mysqli_stmt_close($stmt_11);
		if($skin_mode=='skin'){
			$result = @unlink('../skin/'.$skin_md5.'.png');
		}else{
			$result = @unlink('../ape/'.$skin_md5.'.png');
		}
		if(!$result){
			exit(json_encode(array('msg' => '删除失败','mode' => "1")));
		}
		exit(json_encode(array('msg' => '删除成功','mode' => "2")));
	}
}
if($act=='get_skin_list'){
	exit(json_encode(get_skin_list($mysqli,$_REQUEST['first'],$_REQUEST['last'], $_REQUEST['mode'])));
}
exit(json_encode(array('msg'=>'你状态貌似有点不对劲!','mode'=>'1')));
function get_skin_list($mysqli,$first,$last,$mode){
	if(empty($mysqli)){
		$info['mode']='1';
		$info['msg']='mysqli链接失败?';
		return $info;
	}
	if(empty($mode)){
		$info['mode']='1';
		$info['msg']='你有东西忘记填写了!';
		return $info;		
	}
	if(empty($last)){
		$last=$first;
	}else{
		$first=$last;
	}
	if($mode!='ape' and $mode!='skin'){
		$info['mode']='1';
		$info['msg']='模式有误!';
		return $info;		
	}
	$last=intval($last);
	$first=intval($first);
	$num_1 = ($last - $first);
	$num_2 = ($first - $last);
	if(($num_1>17) or ($num_2<-17)){
		$skin_list['mode']='1';
		$skin_list['msg']='数组错误！';
		return $skin_list;		
	}
	if($mode=='skin'){
		$sql='SELECT * FROM skinlink order by id desc limit ?,16';
		$sql_first='SELECT * FROM skinlink order by id limit 1';
	}else{
		$sql='SELECT * FROM apelink order by id desc limit ?,16';
		$sql_first='SELECT * FROM apelink order by id limit 1';
	}
	$stmt_first = mysqli_prepare($mysqli, $sql_first);
	if(!mysqli_stmt_execute($stmt_first)){
		$skin_list['mode']='1';
		$skin_list['msg']='[first]执行失败';
		return $skin_list;		
	}
	mysqli_stmt_bind_result($stmt_first,$id,$skin_md5,$skin_link,$skin_name);
	mysqli_stmt_fetch($stmt_first);
	mysqli_stmt_close($stmt_first);
	//获取第一个皮肤id
	
	$stmt = mysqli_prepare($mysqli, $sql);
	mysqli_stmt_bind_param($stmt, "i", $first);
	if(!mysqli_stmt_execute($stmt)){
		$skin_list['mode']='1';
		$skin_list['msg']='执行失败';
		return $skin_list;		
	}
	mysqli_stmt_bind_result($stmt,$skin_id,$skin_md5,$skin_link,$skin_name);
	$skin_list['skin_list']=array("");
	$i=0;
    while(mysqli_stmt_fetch($stmt)){
    	$i=$i+1;
    	$str_json=object_array(json_decode($skin_name));
		$skin_arr['skin_id'] = $skin_id;
		$skin_arr['skin_md5'] = $skin_md5;
		$skin_arr['skin_link'] = $skin_link;
		$skin_arr['skin_time'] = date("Y-m-d H:i:s",$str_json['skin_time']);
		$skin_arr['skin_updata_user'] = $str_json['skin_updata_user'];
		$skin_arr['skin_name'] = base64_decode($str_json['skin_name']);
		array_push($skin_list['skin_list'],$skin_arr);
		if($id==$skin_id){
			$skin_list['num']=$i;
			$skin_list['mode']='4';
			$skin_list['msg']='似乎没有更多了！';
			mysqli_stmt_close($stmt);
			return $skin_list;			
			//到达最前事件
		}
    }
	mysqli_stmt_close($stmt);
	if($i==0){
			$skin_list['sql']=$sql;
		$skin_list['mode']='3';
		$skin_list['msg']='似乎没有更多了！';
		return $skin_list;
	}
	if($i<15){
		$skin_list['mode']='4';
	}else{
		$skin_list['mode']='2';
	}
	$skin_list['num']=$i;
	$skin_list['msg']='获取成功!';
	$skin_list['first']=$last+16;
	$skin_list['last']=$last-16;
	return $skin_list;
}
?>