<?php
session_start();
if(!file_exists('../skin_config.php')){
	exit(header("Location: skin_install.php")); 
}
include('../basis_html.php');
$info_sql=config_read();
if(empty($_SESSION['admin_username']) or empty($_SESSION['admin_password'])){
	$a=FALSE;
}else{
	if(($_SESSION['admin_username']!=$info_sql['admin_username']) or ($_SESSION['admin_password']!=$info_sql['admin_password'])){
		$a=FALSE;
	}else{
		$a=TRUE;
	}
}
function html_login(){
?>
<body style=" background:url(../images/bg[3].jpg) repeat fixed!important;"></body>
<div class="am-g">
	<div class="am-u-sm-centered am-u-lg-5 am-u-sm-12" >
		<div class="am-panel am-panel-default am-animation-fade" style="margin-top: 20%;box-shadow:0px 0px 15px #909090;" >
			<div class="am-panel-bd">
				<blockquote>
					<p class="am-kai">
						大智若愚&nbsp;大巧若拙
					</p>
				</blockquote>
				<div class="am-input-group">
					<span class="am-input-group-label">账&nbsp;&nbsp;&nbsp;&nbsp;号</span>
					<input type="text" class="am-form-field" id="login_username" placeholder="账号">
				</div>
				<br>
				<div class="am-input-group">
					<span class="am-input-group-label">密&nbsp;&nbsp;&nbsp;&nbsp;码</span>
					<input type="password" class="am-form-field" id="login_password" placeholder="密码">
				</div>
				<br>
				<div class="am-cf">
					<div class="am-input-group am-fl" style="width: 75%;">
						<span class="am-input-group-label">验证码</span>
						<input type="text" class="am-form-field" id="login_code" placeholder="输入右边的验证码 " required/>
					</div>
					<div class="am-fr" style="width: 22%;">
						<img class="am-thumbnail" src="../skin_code.php" alt="" onclick="newcode()" id="img_code_1" style="width: 100%;height: 40px;" />
					</div>
				</div>
				<!--验证码框架-->
				<button type="submit" class="am-btn am-btn-primary am-btn-block  btn-loading-example" data-am-loading="{spinner: 'circle-o-notch'}" id="ajax_login" onclick="admin_login()">
					登录
				</button>
			</div>
		</div>
	</div>
</div>
<!--登录框架-->
<?php
}
function html_admin(){
?>
<header class="am-topbar am-topbar-inverse admin-header">
  <div class="am-topbar-brand">
    <strong>Oneskin</strong> <small>后台管理模板</small>
  </div>
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
  <div class="am-collapse am-topbar-collapse" id="topbar-collapse">

    <ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right admin-header-list">
      <li class="am-dropdown" data-am-dropdown>
        <a class="am-dropdown-toggle" href="javascript:;">
          <span class="am-icon-users"></span> 管理员
        </a>
      </li>
    </ul>
  </div>
</header>
<div class="am-cf admin-main">
  <!-- sidebar start -->
  <div class="admin-sidebar am-offcanvas" id="admin-offcanvas" style="overflow-x:hidden;overflow-y:hidden;">
    <div class="am-offcanvas-bar admin-offcanvas-bar">
      <ul class="am-list admin-sidebar-list">
        <li id="b0" style="background: #ecf0f1;" class="active_li"><a href="#" onclick="jump(0)"><span class="am-icon-home"></span> 首页</a></li>
        <li id="b1" class="active_li"><a href="#" onclick="jump(1)"><span class="am-icon-check"></span> 修改密码</a></li>
        <li id="b3" class="active_li"><a href="#" onclick="jump(3)"><span class="am-icon-th"></span> 玩家列表</a></li>
        <li id="b4" class="active_li"><a href="#" onclick="jump(4)"><span class="am-icon-table"></span> 皮肤列表</a></li>
        <li id="b5" class="active_li"><a href="#" onclick="jump(5)"><span class="am-icon-pencil-square-o"></span> 配置</a></li>
        <li id="b6" class="active_li"><a href="#" onclick="jump(6)"><span class="am-icon-sign-out"></span> 注销</a></li>
      </ul>
      
      <div class="am-panel am-panel-default admin-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-tag"></span> 关于</p>
          <p>当前版本:3.0.5<br><br>命运怎能停滞不前!</p>
        </div>
      </div>
    </div>
  </div>
  <!-- sidebar end -->

  <!-- content start -->
  <div class="admin-content">
    <div class="admin-content-body" id="admin_body"> 	
    	<!--内容部分-->
    </div>
    <div class="admin-content-body" id="skin_list_div" style="display: none;">
    	<div id="admin_config">
    		<div class="am-cf am-padding">
    			<div class="am-fl am-cf">
    				<strong class="am-text-primary am-text-lg" id="info_title">Skin_list</strong> / <small id="info_title_small">更好的管理皮肤</small>
    			</div><br><hr>
    		</div>
    		<div class="am-g">
    			<div class="am-u-sm-centered am-u-md-9">
    				<div class="am-panel am-panel-primary">
    					<div class="am-panel-hd">修改密码</div>
    					<div class="am-panel-bd">
    						<div class="am-tabs" data-am-tabs="{noSwipe: 1}" id="skin_list">
    							<ul class="am-tabs-nav am-nav am-nav-tabs">
    								<li class="am-active"><a href="#skin">皮肤</a></li>
    								<li><a href="#ape">披风</a></li>
    							</ul>
    							<div class="am-tabs-bd">
    								<div class="am-tab-panel am-active" id="skin">
    									<blockquote><p class="am-text-sm am-text-truncate am-sans-serif">皮肤列表</p></blockquote>
    									<table class="am-table am-table-striped am-table-hover">
    										<thead>
    											<tr><th>皮肤ID</th><th>皮肤MD5</th><th>皮肤地址</th><th>皮肤名</th><th>操作</th></tr>
    										</thead>
    										<tbody id="skin_table"></tbody>
    									</table>
    								</div>
    								<div class="am-tab-panel" id="ape">
    									<blockquote><p class="am-text-sm am-text-truncate am-sans-serif">披风列表</p></blockquote>
    									<table class="am-table am-table-striped am-table-hover">
    										<thead>
    											<tr><th>披风ID</th><th>披风MD5</th><th>披风地址</th><th>披风名</th><th>操作</th></tr>
    										</thead>
    										<tbody id="ape_table"></tbody>
    									</table>    									
    								</div>
    							</div>
    							<div class="am-cf">
    								<br>
    								<div class="am-fl">
    									<button type="button" class="am-btn am-btn-success" id="next_up">上一页</button>
    								</div>
    								<div class="am-fr">
    									<button type="button" class="am-btn am-btn-success" id="next_down">下一页</button>
    								</div>
    							</div>
    						</div> 	    						
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    	<!--内容部分-->
    </div>
    <footer class="admin-content-footer">
      <hr><p class="am-padding-left">© 2016 Fleey.构建于2016/6</p>
    </footer>
  </div>
  <!-- content end -->

</div>

<div class="am-modal am-modal-no-btn" tabindex="-1" id="find_passowrd_modal">
	<div class="am-modal-dialog" style="padding: 7px;">
		<div class="am-modal-hd">
			<h3>
				你将修改<span id="find_title"></span>&nbsp;的密码
			</h3>
			<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
		</div>
		<div class="am-input-group">
			<span class="am-input-group-label">他的新密码</span>
			<input type="text" class="am-form-field" id="user_new_password">
		</div><br>
		<div class="am-input-group">
			<span class="am-input-group-label">再输新密码</span>
			<input type="text" class="am-form-field" id="user_new_again_password">
		</div><br>
		<button type="submit" class="am-btn am-btn-primary am-btn-block  btn-loading-example" data-am-loading="{spinner: 'circle-o-notch'}" id="ajax_change" onclick="change_user()">修改</button>
	</div>
</div>
<?php
}
?>
<!doctype html>
<html class="no-js fixed-layout">
	<head>
		<?php html_inside_css(); ?>
		<link rel="stylesheet" href="../css/skin_admin.css" />
		<link rel="stylesheet" href="../css/jquery/jquery.mCustomScrollbar.css" />
		<title>
			Oneskin管理平台
		</title>
	</head>
	<body>
<!--[if lte IE 9]>
<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请 <a href="http://browsehappy.com/" target="_blank">升级浏览器</a>
  以获得更好的体验！</p>
<![endif]-->		
		<?php
		if (!$a) {html_login();} else {html_admin();}
		?>
		<?php html_inside_js(); ?>
		<script type="text/javascript" src="../js/toaster.js" ></script>
		<script type="text/javascript" src="../js/skin_admin.js" ></script>
		<script type="text/javascript" src="../js/jquery/jquery.mCustomScrollbar.js" ></script>
		<script type="text/javascript" src="../js/jquery/jquery.mousewheel.min.js" ></script>
		<script type='text/javascript'>
		(function($){
			$(window).load(function(){
				$.mCustomScrollbar.defaults.scrollButtons.enable=true; //enable scrolling buttons by default
				$.mCustomScrollbar.defaults.axis="yx"; //enable 2 axis scrollbars by default
				$(".admin-content").mCustomScrollbar({theme:"minimal-dark"});
			});
			})(jQuery);
		</script>
	</body>
</html>