<?php
//本页面用于简洁化输入验证码而存在!
session_start();
include('basis_html.php');//载入配置文件
if(@$_SESSION['look_time']>time()){
	exit(error('505', '[风控系统]系统检测到您疑似非法爆破密匙!请30分钟后再访问!'));
}else{
	unset($_SESSION['look_time']);
}
@$_SESSION['look_number']+=1;
if($_SESSION['look_number']>=10){
	$_SESSION['look_time']=time()+1800;
	exit(error('505', '[风控系统]系统检测到您疑似非法爆破密匙!请30分钟后再访问!'));
}
//风险控制系统
$info_sql = config_read();
//读入配置
$mysqli = mysqli_connect($info_sql['db_host'], $info_sql['db_username'], $info_sql['db_password'], $info_sql['db_name'], $info_sql['db_port']);

	if ((!empty($_POST['act']) and !empty($_POST['key'])) or (!empty($_GET['act']) and !empty($_GET['key']))) {
		if (!empty($_POST['act']) and !empty($_POST['key'])) {
			if (empty($_POST['password']) or empty($_POST['password_again']) or empty($_POST['username'])) {
				exit(json_encode(array('msg' => '请填写完整!', 'mode' => '1')));
			}
			if($_POST['password']!=$_POST['password_again']){
				exit(json_encode(array('msg' => '两次密码不一致请重新确认!', 'mode' => "1")));
			}
			if (!preg_match(base64_decode($info_sql['regular_password']), $_POST['password'])) {
				exit(json_encode(array('msg' => '密码格式错误', 'mode' => "1")));
			}
			$sql = 'select email,time from skin_email where code=?';
			$stmt_email = $mysqli -> prepare($sql);
			$stmt_email -> bind_param('s',$_POST['key']);
			$stmt_email -> execute();
			$stmt_email -> bind_result($email_email, $email_time);
			$stmt_email -> fetch();
			$stmt_email -> close();
			if (empty($email_email)) {
				exit(json_encode(array('msg' => '您的密匙不正确!', 'mode' => "1")));
			}
			if ($email_time < time()) {
				exit(json_encode(array('msg' => '您的密匙超时请重新获取!', 'mode' => "1")));
			}
			$n = change_password($mysqli, $info_sql, $_POST['password'], $_POST['username']);
			if ($n['mode'] == '2') {
				update_email($mysqli, $email_email);
				unset($_SESSION['look_number']);
				exit(json_encode($n));
			} else {
				exit(json_encode($n));
			}
		}
	} else {
		exit(error('500', '请勿随意访问本页面!'));
	}
//ajax部分
?>
<!doctype html>
<html class="no-js fixed-layout">
	<head>
		<title>OneSkin</title>
		<?php html_css(); ?>
	</head>
	<body style="background:url(images/bg[4].jpg);">
		<div class="am-g">
			<div class="am-u-md-8 am-u-sm-12 am-u-sm-centered">
				<div class="am-panel am-panel-default" style="margin-top: 14%;">
					<div class="am-panel-bd">
						<div class="am-vertical-align">
							<div class="am-vertical-align-middle" style="width: 100%;">
							<?php
							 switch ($_GET['act']) {
							 	case 'check_email':
									if(empty($_SESSION['email_check'])){
										exit(error('502', '密匙过期或不存在!'));
									}
									if($_GET['key']!=$_SESSION['email_check']){
										exit(error('500', '验证邮箱密匙错误!'));
									}
									if(!update_mysqli_config($mysqli,'smtp_config',$_SESSION['email_config'])){
										exit(error('500', '写入数据失败!'));
									}else{
										unset($_SESSION['look_number']);
										html_success('恭喜您！通过了邮箱验证！','注册和找回密码功能已开启!');
										unset($_SESSION['email_check']);
										unset($_SESSION['email_config']);
									}
							 	break;
                                case 'register':
                                $sql='select user,email,time from skin_email where code=?';
                                $stmt_email=$mysqli->prepare($sql);
                                $stmt_email->bind_param('s',$_GET['key']);
                                $stmt_email->execute();
                                $stmt_email->bind_result($email_user,$email_email,$email_time);
                                $stmt_email->fetch();
                                $stmt_email->close();
								if(empty($email_user) or ($email_time<time())){
									html_error_1('很抱歉,发现一个问题','您的密匙不正确或已过期!请重试或重新发送邮件获取!');
								}else{
									$str_json=object_array(json_decode($email_user));
									$username=$str_json['username'];//获取用户名
									$password=$str_json['password'];//获取密码
									$password_md5=md5($password);
									if($info_sql['mode']=='none'){
										$sql="INSERT INTO skinme(user,pass,email) VALUES(?,?,?)";//sql注册部分
										$stmt_3=$mysqli->prepare($sql);
										$stmt_3->bind_param('sss',$username,$password_md5,$email_email);
										if($stmt_3->execute()){
											update_email($mysqli, $email_email);
											unset($_SESSION['look_number']);
											html_success('恭喜您！已经成功注册！'.$username,'您现在可以回到首页登陆并使用了!');
										}else{
											error('500', '[Oneskin]新建用户错误!请重试!');
										}
										$stmt_3->close();	
									}
									if($info_sql['mode']=='authme'){
										$sql_authme="INSERT INTO ".$info_sql['table']." (".$info_sql['username'].",".$info_sql['realname'].",".$info_sql['password'].") VALUES (?,?,?)";//sql注册部分
										$stmt_authme_new=$mysqli->prepare($sql_authme);
										//计算开始
										$salt = getRandChar(16);//获取16位散列
										$password_sha256 = hash('sha256', $password);
										$password_sha256 = hash("sha256", $password_sha256.$salt);//计算出sha256
										$password_sha256 = '$SHA$'.$salt.'$'.$password_sha256;
										$username_s = strtolower($username);
										//计算结束
										$stmt_authme_new->bind_param("sss",$username_s,$username,$password_sha256);
										if($stmt_authme_new->execute()){
											$sql="INSERT INTO skinme(user,pass,email) VALUES(?,?,?)";//sql注册部分
											$stmt_3=$mysqli->prepare($sql);
											$stmt_3->bind_param('sss',$username,$password_md5,$email_email);
											if($stmt_3->execute()){
												update_email($mysqli, $email_email);
												unset($_SESSION['look_number']);
												html_success('恭喜您！已经成功注册！'.$username,'您现在可以回到首页登陆并使用了!');
											}else{
												error('500', '[Oneskin]新建用户错误!请重试!');
											}					
											$stmt_3->close();				
										}else{
											error('500', '[Authme]新建用户错误!请重试!');
										}	
										$stmt_authme_new->close();							
									}
									if($info_sql['mode']=='beelogin'){
										$sql_beelogin="INSERT INTO ".$info_sql['table']." (".$info_sql['username'].",".$info_sql['password'].",".$info_sql['password_salt'].") VALUES (?,?,?)";
										$stmt_beelogin_new=$mysqli->prepare($sql_beelogin);
										//计算开始
										$salt = getRandChar(6);//获取随机6位散列
										$password_salt = md5(md5($password).$salt);//计算出密码
										//计算结束
										$stmt_beelogin_new->bind_param("sss",$username,$password_salt,$salt);
										if($stmt_beelogin_new->execute()){
											$sql="INSERT INTO skinme(user,pass,email) VALUES(?,?,?)";//sql注册部分
											$stmt_3=$mysqli->prepare($sql);
											$stmt_3->bind_param('sss',$username,$password_md5,$email_email);
											if($stmt_3->execute()){
												update_email($mysqli, $email_email);
												unset($_SESSION['look_number']);
												html_success('恭喜您！已经成功注册！','您现在可以回到首页登陆并使用了!');
											}else{
												error('500', '[Oneskin]新建用户错误!请重试!');
											}	
											$stmt_3->close();											
										}else{
											error('500', '[Beelogin]新建用户错误!请重试!');
										}
										$stmt_beelogin_new->close();						
									}
								}
								break;
                                case 'find_password':
                                $sql='select user,email,time from skin_email where code=?';
                                $stmt_email=$mysqli->prepare($sql);
                                $stmt_email->bind_param('s',$_GET['key']);
                                $stmt_email->execute();
                                $stmt_email->bind_result($email_user,$email_email,$email_time);
                                $stmt_email->fetch();
                                $stmt_email->close();
								if(empty($email_user) or ($email_time<time())){
									html_error_1('很抱歉,发现一个问题','您的链接不正确或已过期!请重试或重新发送邮件获取!');
								}else{
									$str_json=object_array(json_decode($email_user));
									if($str_json['act']!='find_password'){
										error('503', '[风控系统]后台已记录,请不要在尝试此操作!');
									}else{
										html_find_password($str_json['username'],$_GET['key']);
									}
								}								
									break;
							 	default:
							 	error('499', '发生了错误，ERROR CODE:499');
							 	break;
							 }
							?>								
							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
<script src="http://s.amazeui.org/assets/2.x/js/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.amazeui.org/amazeui/2.7.0/js/amazeui.min.js" ></script>
<script type="text/javascript" src="js/toaster.js" ></script>
	</body>
</html>
<?php
function html_success($title,$contain){?>
	<h2 class="am-text-center">
		<?php echo $title; ?>
	</h2>
	<hr>
	<p class="am-text-center">
		<a class="am-icon-btn am-success am-icon-shield">
		</a>
		&nbsp;&nbsp;<?php echo $contain; ?>
	</p><br>
	<p class="am-text-center"><a title="返回首页" href="index.php">返回首页</a></p>
	<!--检查验证邮箱部分-->
</p>
<?php	
}
function update_email($mysqli,$email){
	$sql = "UPDATE skin_email SET time=?,user=? where email=?";//更新玩家邮箱设置
	$stmt_user=$mysqli->prepare($sql);		
	$time=time();
	$json='';
	$stmt_user->bind_param("sss",$time,$json,$email);
	$stmt_user->execute();
	$stmt_user->close();	
}
function error($error_number,$contain){
?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>系统发生错误</title>
<style type="text/css">
*{ padding: 0; margin: 0; }
html{ overflow-y: scroll; }
body{ background: #fff; font-family: '微软雅黑'; color: #333; font-size: 16px; }
img{ border: 0; }
.error{ padding: 24px 48px; }
.face{ font-size: 100px; font-weight: normal; line-height: 120px; margin-bottom: 12px; }
h1{ font-size: 32px; line-height: 48px;color: #34495e; }
.error .content{ padding-top: 10px}
.error .info{ margin-bottom: 12px; }
.error .info .title{ margin-bottom: 3px; }
.error .info .title h3{ color: #000; font-weight: 700; font-size: 16px; }
.error .info .text{ line-height: 24px; }
.copyright{ padding: 12px 48px; color: #999; }
.copyright a{ color: #000; text-decoration: none; }
</style>
</head>
<body>
<div class="error">
<p class="face">:(</p>
<h1>错误编号&nbsp;&nbsp;<?php echo $error_number; ?></h1>
<div class="content">
</div>
</div>
<div class="copyright">
<p><h3>错误详情：</h3></p><br>
<p><?php echo $contain; ?></p><br>
<p><a title="返回首页" href="index.php">返回首页</a></p>
</div>
</body>	
<?php		
	}
function html_error_1($title,$contain){ ?>
	<h2 class="am-text-center">
		<?php echo $title; ?>
	</h2>
	<hr>
	<p class="am-text-center">
		<a class="am-icon-btn am-warning am-icon-warning">
		</a>
		&nbsp;&nbsp;<?php echo $contain; ?>
	</p><br>
	<p class="am-text-center"><a title="返回首页" href="index.php">返回首页</a></p>
	<!--检查验证邮箱部分-->
</p>
<?php	
}
function html_find_password($username,$key){ ?>
	
	<h2 class="am-text-center" id="find_password_title">
		找回密码-"<?php echo $username; ?>"
	</h2>	
	<hr>
	<div id="find_password_body">		
	<div class="am-input-group">
		<span class="am-input-group-label"><i class="am-icon-unlock-alt am-icon-fw"></i></span>
		<input type="text" class="am-form-field" id="password" placeholder="输入新密码">
	</div><br>
	<div class="am-input-group">
		<span class="am-input-group-label"><i class="am-icon-lock am-icon-fw"></i></span>
		<input type="text" class="am-form-field" id="password_again" placeholder="重复输入新密码">
	</div><br>
	<button type="button" class="am-btn am-btn-primary am-btn-block btn-loading-example" id="v1" onclick="change_password('<?php echo $key; ?>','<?php echo $username; ?>','<?php echo $email; ?>')" data-am-loading="{spinner: 'circle-o-notch', loadingText: '加载中...'}">确认</button>
	</div>
	<script type="text/javascript">
		function change_password(key,username,email){
			$('#v1').button('loading');
			$.ajax({
				type:"post",
				url:"skin_just.php",
				data:{
					act:'change_password',
					key:key,
					username:username,
					password:document.getElementById('password').value,
					password_again:document.getElementById('password_again').value,
					email:email
				},
				dataType:'json',
				success:function(data){
					if(data.mode=='1'){
						$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
					}
					if(data.mode=='2'){
						document.getElementById('find_password_title').innerText='密码已更改!';
						document.getElementById('find_password_body').innerHTML='<p class="am-text-center"><a class="am-icon-btn am-success am-icon-shield"></a>&nbsp;&nbsp;点击返回首页返回主页面</p><br><p class="am-text-center"><a title="返回首页" href="index.php">返回首页</a></p>';
						$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
					}
					$('#v1').button('reset');
				}
			});
		}
	</script>
<?php
}
?>