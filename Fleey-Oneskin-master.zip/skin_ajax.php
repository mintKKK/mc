<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING^E_DEPRECATED);
session_start();
include('basis_html.php');
$act=htmlspecialchars($_REQUEST['act']);
$groups=htmlspecialchars($_REQUEST['groups']);
if(empty($act)){
	exit(json_encode(array('mode'=>'1','msg'=>'你似乎不在状态?')));
}
if(!empty($groups)){//权限组部分
	if(!file_exists('skin_config.php')){
		exit(json_encode(array('mode'=>'1','msg'=>'你似乎还没有安装Oneskin呢')));
	}
	$info_sql=config_read();//读入配置
	$mysqli=mysqli_connect($info_sql['db_host'],$info_sql['db_username'], $info_sql['db_password'], $info_sql['db_name'], $info_sql['db_port']);
	if($groups=='user'){//用户权限
		if(empty($_SESSION['user_username']) or empty($_SESSION['user_password'])){
			exit(json_encode(array('mode'=>'1','msg'=>'你权限似乎有点不对劲哟~')));
		}
		if($act=='add_skin'){
			$mode=$_REQUEST['mode'];
			$skin_id=$_REQUEST['skin_id'];
			if(empty($mode) or empty($skin_id) or ($mode!='skin' and $mode!='ape')){
				exit(json_encode(array('mode'=>'1','msg'=>'状态有误!')));
			}
			if($mode=='skin'){
				$sql_skin="SELECT list_skin FROM skinme WHERE user=?";//查询命令
				$sql="SELECT * FROM skinlink WHERE id=?";//查询命令
			}
			if($mode=='ape'){
				$sql_skin="SELECT list_ape FROM skinme WHERE user=?";//查询命令
				$sql="SELECT * FROM apelink WHERE id=?";//查询命令
			}
			$stmt_skin_3 = $mysqli->prepare($sql);
			$stmt_skin_3->bind_param('s', $skin_id);//sql预处理交互
			$stmt_skin_3->execute();//执行sql
			$stmt_skin_3->bind_result($skinid,$skinmd5,$skinlink,$skinname);//获取信息
			$stmt_skin_3->fetch();
			$stmt_skin_3->close();	
			if(empty($skinlink)){
				exit(json_encode(array('msg' => '[skin]很抱歉没有找到这个皮肤的ID','mode' => "1")));
			}else{
				$stmt_skin = $mysqli->prepare($sql_skin);
				$stmt_skin->bind_param('s', $_SESSION['user_username']);//sql预处理交互
				$stmt_skin->execute();//执行sql
				$stmt_skin->bind_result($list_skin);//获取信息
				$stmt_skin->fetch();
				$stmt_skin->close();	
				$j = strstr($list_skin, "*".$skin_id."*,");
				if($j !== FALSE){
					exit(json_encode(array('msg' => '[skin]添加到列表失败!或许列表已经有这个皮肤了','mode' => "1")));
				}else{
					$skin_list = $list_skin."*".$skinid."*,";
					if($mode=='skin'){
						$sql = "UPDATE skinme SET list_skin=? where user=?";//记录玩家使用皮肤
					}
					if($mode=='ape'){
						$sql = "UPDATE skinme SET list_ape=? where user=?";//记录玩家使用皮肤
					}
					$stmt_user=$mysqli->prepare($sql);
					$stmt_user->bind_param("ss",$skin_list,$_SESSION['user_username']);
					$stmt_user->execute();
					$stmt_user->close();			
					exit(json_encode(array('msg' => '已经成功添加到皮肤列表!','mode' => "2")));
				}
			}			
		}
		if($act=='set_skin'){
			$mode=$_REQUEST['mode'];
			$id=$_REQUEST['id'];
			if(empty($mode) or empty($id) or ($mode!='skin' and $mode!='ape')){
				exit(json_encode(array('mode'=>'1','msg'=>'模式错误？')));
			}
			if($mode=='skin'){
				$sql="SELECT skinmd5 FROM skinme WHERE user=?";//查询命令
				$sql_skin="SELECT md5 FROM skinlink WHERE id=?";//查询命令
				$sql_updata = "UPDATE skinme SET skinmd5=? where user=?";//记录玩家使用皮肤
			}
			if($mode=='ape'){
				$sql="SELECT apemd5 FROM skinme WHERE user=?";//查询命令
				$sql_skin="SELECT md5 FROM apelink WHERE id=?";//查询命令
				$sql_updata = "UPDATE skinme SET apemd5=? where user=?";//记录玩家使用皮肤
			}
			$stmt_3=$mysqli->prepare($sql);
			$stmt_3->bind_param('s',$_SESSION['user_username']);	
			$stmt_3->execute();//执行sql
			$stmt_3->bind_result($user_skin_md5);//获取信息	
			$stmt_3->fetch();
			$stmt_3->close();
			$stmt_skin = $mysqli->prepare($sql_skin);
			$stmt_skin->bind_param('s', $id);//sql预处理交互
			$stmt_skin->execute();//执行sql
			$stmt_skin->bind_result($skin_md5);//获取信息
			$stmt_skin->fetch();
			$stmt_skin->close();	
			if($skin_md5==$user_skin_md5){
				exit(json_encode(array('msg' => '貌似你这个就是主披风?','mode' => "1")));
			}
			$stmt_user=$mysqli->prepare($sql_updata);
			$stmt_user->bind_param("ss",$skin_md5,$_SESSION['user_username']);
			$stmt_user->execute();
			$stmt_user->close();
			if($mode=='skin'){
				copy("skin/".$skin_md5.".png", "show_skin/".$_SESSION['user_username'].".png");	
			}else{
				copy("ape/".$skin_md5.".png", "show_ape/".$_SESSION['user_username'].".png");	
			}	
			exit(json_encode(array('msg' => '成功切换皮肤','mode' => "2")));
		}
		if($act=='del_skin'){
			$mode=$_REQUEST['mode'];
			$id=$_REQUEST['id'];
			if(empty($mode) or empty($id) or ($mode!='skin' and $mode!='ape')){
				exit(json_encode(array('mode'=>'1','msg'=>'模式错误？')));
			}
			if($mode=='skin'){
				$sql="SELECT list_skin FROM skinme WHERE user=?";//查询命令
				$sql_updata = "UPDATE skinme SET list_skin=? where user=?";//记录玩家使用皮肤
			}
			if($mode=='ape'){
				$sql="SELECT list_ape FROM skinme WHERE user=?";//查询命令
				$sql_updata = "UPDATE skinme SET list_ape=? where user=?";//记录玩家使用皮肤
			}
			$stmt_3=$mysqli->prepare($sql);
			$stmt_3->bind_param('s',$_SESSION['user_username']);	
			$stmt_3->execute();//执行sql
			$stmt_3->bind_result($list_skin);//获取信息	
			$stmt_3->fetch();
			$stmt_3->close();
			$j = strpos($list_skin, "*".$id."*,");
			if($j === false){
				exit(json_encode(array('msg' => '移除失败！','mode' => "1")));
			}else{
				$skin_list = str_replace("*".$id."*,","",$list_skin);//处理皮肤列表
				$stmt_user=$mysqli->prepare($sql_updata);
				$stmt_user->bind_param("ss",$skin_list,$_SESSION['user_username']);
				$stmt_user->execute();
				$stmt_user->close();
				exit(json_encode(array('msg' => '移除成功!','mode' => "2")));			
			}			
		}
		if($act=='get_skin_info'){
			$mode=$_REQUEST['mode'];
			$select_mode=$_REQUEST['select_mode'];
			$skin_id=str_replace("'", '',$_REQUEST['id']);
			$skin_id=str_replace('"', '',$skin_id);
			$skin_md5=str_replace("'", '',$_REQUEST['md5']);
			$skin_md5=str_replace('"', '',$skin_md5);
			if(($mode!='select_md5' and $mode!='select_id') or ($select_mode!='skin' and $select_mode!='ape')){
				exit(json_encode(array('mode'=>'1','msg'=>'模式错误！')));
			}
			if($mode=='select_md5' and !empty($skin_md5)){
				if($select_mode=='skin'){
					$sql_select="SELECT * FROM skinlink WHERE md5=".$skin_md5;//查询命令
				}
				if($select_mode=='ape'){
					$sql_select="SELECT * FROM apelink WHERE md5=".$skin_md5;//查询命令
				}
			}//查询md5模式
			if($mode=='select_id' and !empty($skin_id)){
				if($select_mode=='skin'){
					$sql_select="SELECT * FROM skinlink WHERE id=".$skin_id;//查询命令
				}
				if($select_mode=='ape'){
					$sql_select="SELECT * FROM apelink WHERE id=".$skin_id;//查询命令
				}				
			}//查询id模式
			$stmt_2=$mysqli->prepare($sql_select);
			$stmt_2->execute();//执行sql
			$stmt_2->bind_result($id,$md5,$skin_link,$skin_name);//获取信息
			$stmt_2->fetch();
			$stmt_2->close();	
			if(empty($id)){
				exit(json_encode(array('mode'=>'1','msg'=>'查询失败！'.$c)));
			}		
			$str=object_array(json_decode($skin_name));
			$info['skin_md5']=$md5;
			if($select_mode=='skin'){
				$info['skin_link']='skin_ajax.php?act=preview&mode=skin&groups=user&id='.$id.'&preview_mode=1';	
			}else{
				$info['skin_link']='skin_ajax.php?act=preview&mode=ape&groups=user&id='.$id.'&preview_mode=1';
			}
			if(empty($id)){
				$id='这个皮肤可能被管理员删了哟~';
			}
			$info['skin_id']=$id;
			$info['skin_name']=base64_decode($str['skin_name']);
			$info['skin_time']=date("Y-m-d H:i:s",$str['time']);
			$info['skin_updata_user']=$str['updata_user'];
			$info['mode']='2';
			$info['msg']='获取成功!';
			exit(json_encode($info));
		}
		if($act=='preview'){
			$mode=$_REQUEST['mode'];
			$skin_id=$_REQUEST['id'];
			$preview_mode=$_REQUEST['preview_mode'];
			if(empty($mode) or ($mode!='skin' and $mode!='ape')){
				exit(json_encode(array('mode'=>'1','msg'=>'你模式似乎有点不对劲!')));
			}
			if(empty($skin_id)){
				exit(json_encode(array('mode'=>'1','msg'=>'你ID似乎没有填写')));
			}
			if($mode=='skin'){
				$sql_select="SELECT * FROM skinlink WHERE id=?";//查询命令
			}
			if($mode=='ape'){
				$sql_select="SELECT * FROM apelink WHERE id=?";//查询命令
			}
			$stmt_1=$mysqli->prepare($sql_select);
			$stmt_1->bind_param('i',$skin_id);
			$stmt_1->execute();//执行sql
			$stmt_1->bind_result($id,$md5,$skin_link,$skin_name);//获取信息
			$stmt_1->fetch();
			$stmt_1->close();		
			if($mode=='ape'){
				$fp=fopen($skin_link,"r")or die("不能打开 ".$skin_link); 	
				Header("Content-type: image/png");
				exit(fread($fp,filesize($skin_link)));				
			}
			if(!empty($preview_mode)){
				$l=FALSE;
			}else{
				$l=TRUE;
			}
			$l1=sys_get_temp_dir()."/".rand(1000000,999999999);
			$pic=file_get_contents(htmlspecialchars($skin_link));
			if(empty($pic))return false;
			if(!file_put_contents($l1,$pic))return false;
			$arr=getimagesize($l1);
			if(!$arr)return false;
			Header("Content-type: image/png");
			if($arr[0]!=$arr[1]||$arr[0]<64){
				unlink($l1);
				exit(imagepng(skin_preview(null,null,topng($pic),$l)));
			}
			$pic=skin_18to17($l1);
			unlink($l1);
			exit(imagepng(skin_preview(null,null,$pic,$l)));	
		}
		if($act=='get_warehouse_list'){//获取皮肤仓库列表
			$sql_user="SELECT apemd5,list_ape,skinmd5,list_skin FROM skinme WHERE user=?";//查询命令
			$stmt_1=$mysqli->prepare($sql_user);
			$stmt_1->bind_param('s',$_SESSION['user_username']);
			$stmt_1->execute();//执行sql
			$stmt_1->bind_result($apemd5,$list_ape,$skinmd5,$list_skin);//获取信息
			$stmt_1->fetch();
			$stmt_1->close();
			if(empty($list_ape)){//披风列表没有
				$info['list_ape_mode']='1';
			}else{
				$info['list_ape']=$list_ape;
			}
			if(empty($list_skin)){//皮肤列表没有
				$info['list_skin_mode']='1';
			}else{
				$info['list_skin']=$list_skin;
			}
			if(empty($apemd5)){
				$info['apemd5']='../images/ape_1.png';
			}else{
				$info['apemd5']='../ape/'.$apemd5.'.png';
			}
			if(empty($skinmd5)){
				$info['skinmd5']='../images/skin_1.png';
			}else{
				$info['skinmd5']='../skin/'.$skinmd5.'.png';
			}
			exit(json_encode($info));
		}
		if($act=='updata_skin'){//上传状态
			$mode=$_POST['mode'];//获取上传模式
			$img_pic=$_FILES['file_pic'];//上传的图片
			if(empty($_POST['skin_name'])){
				exit(json_encode(array('mode'=>'1','msg'=>'你皮肤名空了哟~')));
			}
			if(empty($mode)){
				exit(json_encode(array('mode'=>'1','msg'=>'你似乎不在状态!')));
			}
			if($mode=='skin' or $mode=='ape'){
				$img_name=cleanAll($_POST['skin_name']);//获取并过滤皮肤名
				if(strlen($img_name)>15){
					exit(json_encode(array('msg' => '皮肤名称不能超过15个字符！','mode' => "1")));
				}
				if($img_pic['type'] != "image/png"){
					exit(json_encode(array('msg' => '上传图片格式只能png','mode' => "1")));
				}
				$img_name=base64_encode($img_name);//base64编码 编译mysql存储
				if($img_pic['size']>2*1024*1024){
					exit(json_encode(array('msg' => '上传的图片不能大于2mb!','mode' => "1")));
				}
				//判断部分结束
				$PSize = filesize($img_pic['tmp_name']);//获取皮肤大小
				$picturedata = addslashes(fread(fopen($img_pic['tmp_name'], "r"), $PSize));//二进制化图片
				$img_md5 = md5($picturedata);//计算图片md5					
				//计算文件md5结束
				if($mode=='skin'){
					$sql="SELECT id FROM skinlink WHERE md5=?";//查询命令
					$sql_list="SELECT list_skin FROM skinme WHERE user=?";//查询命令	
					$sql_new = "INSERT INTO skinlink (md5,skin,name) VALUES (?,?,?)";//存储皮肤
					$skin_link = "skin/".$img_md5.".png";
					$sql_select_skin="SELECT id FROM skinlink WHERE md5=?";//查询命令
					$sql_updata_skin = "UPDATE skinme SET list_skin=? where user=?";//记录玩家使用皮肤
				}
				if($mode=='ape'){
					$sql="SELECT id FROM apelink WHERE md5=?";//查询命令	
					$sql_list="SELECT list_ape FROM skinme WHERE user=?";//查询命令
					$sql_new = "INSERT INTO apelink (md5,ape,name) VALUES (?,?,?)";//存储皮肤
					$skin_link = "ape/".$img_md5.".png";
					$sql_select_skin="SELECT id FROM apelink WHERE md5=?";//查询命令
					$sql_updata_skin = "UPDATE skinme SET list_ape=? where user=?";//记录玩家使用皮肤
				}
				$stmt_skin = $mysqli->prepare($sql);
				$stmt_skin->bind_param('s', $img_md5);//sql预处理交互
				$stmt_skin->execute();//执行sql
				$stmt_skin->bind_result($id);//获取信息
				$stmt_skin->fetch();
				$stmt_skin->close();
				//检测数据库是否有重复皮肤数据	
				if(empty($id)){
					if($mode=='skin'){
						move_uploaded_file($img_pic['tmp_name'],"skin/".$img_md5.".png") or die(json_encode(array('msg' => '移动文件失败！请检查权限！','mode' => "1")));//执行失败输出错误;
						$img_info = getimagesize("skin/".$img_md5.".png"); 			
						if($img_info[2]!=3){
							unlink("skin/".$img_md5.".png"); 
							exit(json_encode(array('msg' => '上传图片格式只能png','mode' => "1")));
						}				
						if($img_info[0]>128 or $img_info[1]>128){
							unlink("skin/".$img_md5.".png"); 
							exit(json_encode(array('msg' => '文件样式有点不对劲啊！','mode' => "1")));							
						}
					}
					if($mode=='ape'){
						move_uploaded_file($img_pic['tmp_name'],"ape/".$img_md5.".png") or die(json_encode(array('msg' => '移动文件失败！请检查权限！','mode' => "1")));//执行失败输出错误;
						$img_info = getimagesize("ape/".$img_md5.".png"); 
						if($img_info[2]!=3){
							unlink("ape/".$img_md5.".png"); 
							exit(json_encode(array('msg' => '上传图片格式只能png','mode' => "1")));
						}	
						if($img_info[0]>128 or $img_info[1]>128){
							unlink("skin/".$img_md5.".png"); 
							exit(json_encode(array('msg' => '文件样式有点不对劲啊！','mode' => "1")));							
						}													
					}
					
					$stmt_skin_new=$mysqli->prepare($sql_new);
					$skin_name=json_encode(array('skin_name'=>$img_name,'updata_user'=>$_SESSION['user_username'],'time'=>time()));
					$stmt_skin_new->bind_param('sss',$img_md5,$skin_link,$skin_name);
					$stmt_skin_new->execute();//执行sql
					$stmt_skin_new->close();//关闭							
				}		
				//移动文件		
				//数据库存储皮肤数据			
				if(empty($id)){
					$stmt_skin = $mysqli->prepare($sql_select_skin);		
					$stmt_skin->bind_param('s', $img_md5);//sql预处理交互
					$stmt_skin->execute();//执行sql
					$stmt_skin->bind_result($id);//获取信息
					$stmt_skin->fetch();
					$stmt_skin->close();					
				}		
				//数据库查询皮肤
				$stmt_user=$mysqli->prepare($sql_list);
				$stmt_user->bind_param('s',$_SESSION['user_username']);
				$stmt_user->execute();//执行sql
				$stmt_user->bind_result($list_skin);//获取信息
				$stmt_user->fetch();
				$stmt_user->close();		
				//获取用户信息	
				$seek_skin = strpos($list_skin, "*".$id."*");
				//审查皮肤是否重复
				if($seek_skin!==FALSE){
					exit(json_encode(array('msg' => '你的仓库内似乎已经有这个皮肤','mode' => "1")));
				}else{
					$list_skin.="*".$id."*,";//结构化皮肤数据
					$stmt_user=$mysqli->prepare($sql_updata_skin);
					$stmt_user->bind_param("ss",$list_skin,$_SESSION['user_username']);
					$stmt_user->execute();
					$stmt_user->close();	
					//更新玩家数据					
				}
				if(empty($id)){
					exit(json_encode(array('msg' => '成功上传','mode' => "2")));		
				}else{
					exit(json_encode(array('msg' => '已经为你秒存!','mode' => "2")));		
				}
			}else{
				exit(json_encode(array('mode'=>'1','msg'=>'你似乎模式有点不对劲!')));	
			}
		}
	}
	if($groups=='admin'){//管理员权限
		if(($_SESSION['admin_username']!=$info_sql['admin_username']) or ($_SESSION['admin_password']!=$info_sql['admin_password'])){//判断权限
			exit(html_error('501','你权限似乎有点不对劲!'));
		}
		switch ($act) {
			case 'save_config_title'://保存皮肤站名
		    if(empty($_POST['title'])){
		    	exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了？')));
		    }
			$info_sql['title']=$_POST['title'];
			writefile("skin_config.php", "<?php ".'$sql_config'."='".base64_encode(json_encode($info_sql))."'; ?>");
			exit(json_encode(array('mode'=>'2','msg'=>'成功修改数据')));			
			    break;
			case 'save_config_smtp'://保存邮箱配置
			if(empty($_POST['smtp_host']) or empty($_POST['smtp_port']) or empty($_POST['smtp_username']) or empty($_POST['smtp_password']) or empty($_POST['smtp_ssl'])){
				exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了？')));
			}
			if(($_POST['smtp_ssl']!='yes') and ($_POST['smtp_ssl']!='no')){
				exit(json_encode(array('mode'=>'1','msg'=>'你似乎在测试bug？')));
			}
			if($_POST['smtp_ssl']=='yes'){
				$ssl=TRUE;
			}else{
				$ssl=FALSE;
			}
			$email_config['smtp_host']=$_POST['smtp_host'];
			$email_config['smtp_port']=$_POST['smtp_port'];
			$email_config['smtp_username']=$_POST['smtp_username'];
			$email_config['smtp_password']=$_POST['smtp_password'];
			$email_config['smtp_ssl']=$_POST['smtp_ssl'];
			if(update_mysqli_config($mysqli,'smtp_config',json_encode($email_config))){
				exit(json_encode(array('mode'=>'2','msg'=>'保存成功')));
			}else{
				exit(json_encode(array('mode'=>'1','msg'=>'保存失败')));
			}								
				break;
			case 'smtp_get_code'://发送验证邮件
			if(empty($_POST['send_username']) or empty($_POST['smtp_host']) or empty($_POST['smtp_port']) or empty($_POST['smtp_username']) or empty($_POST['smtp_password']) or empty($_POST['smtp_ssl'])){
				exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了？')));
			}
			if(($_POST['smtp_ssl']!='yes') and ($_POST['smtp_ssl']!='no')){
				exit(json_encode(array('mode'=>'1','msg'=>'你似乎在测试bug？')));
			}
			if($_POST['smtp_ssl']=='yes'){
				$ssl=TRUE;
			}else{
				$ssl=FALSE;
			}
			$random=getRandChar('9');//获取九位随机字符
			$email_config['smtp_host']=$_POST['smtp_host'];
			$email_config['smtp_port']=$_POST['smtp_port'];
			$email_config['smtp_username']=$_POST['smtp_username'];
			$email_config['smtp_password']=$_POST['smtp_password'];
			$email_config['smtp_ssl']=$_POST['smtp_ssl'];
			$_SESSION['email_check']=$random;//存入session
			$_SESSION['email_config']=json_encode($email_config);//存储数据
			$url=dirname('http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"]).'/skin_just.php?act=check_email&key='.$random; 
			if(send_email($_POST['send_username'], $ssl, $_POST['smtp_host'],$_POST['smtp_port'],$_POST['smtp_username'],$_POST['smtp_password'],'关于你的服务器开启找回密码服务','请进行点击<a color="#3498db" href="'.$url.'">这个</a>按钮进行访问页面或手动访问以下链接<br><br>'.$url)){
				exit(json_encode(array('mode'=>'2','msg'=>'发送邮件成功')));
			}else{
				exit(json_encode(array('mode'=>'1','msg'=>'发送邮件失败')));
			}
			    break;
			case 'admin_config'://读入配置界面
				exit(html_admin_config($info_sql,$mysqli));
				break;	
			case 'admin_index'://获取主页面
			exit(html_admin_index($mysqli, $info_sql));
			break;
			case 'admin_change_password'://修改密码
			exit(html_admin_change_password());
			break;
			case 'admin_player_list'://用户列表
			exit(html_player_list($mysqli,$info_sql));
			break;
			case 'save_config_db'://保存数据库配置
				if((empty($_POST['db_host']) or empty($_POST['db_port']) or empty($_POST['db_username']) or empty($_POST['db_name'])) and empty($_POST['db_password'])){
					exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了？')));
				}
				$info_sql['db_host']=$_POST['db_host'];
				$info_sql['db_port']=$_POST['db_port'];
				$info_sql['db_username']=$_POST['db_username'];
				$info_sql['db_password']=$_POST['db_password'];
				$info_sql['db_name']=$_POST['db_name'];
				writefile("skin_config.php", "<?php ".'$sql_config'."='".base64_encode(json_encode($info_sql))."'; ?>");
				exit(json_encode(array('mode'=>'2','msg'=>'成功修改数据')));
				break;
			default:
				exit(html_error('502','你似乎在测试Bug?'));
				break;
		}
	}
	exit(html_error('500','你似乎有点不太对劲!'));
}
if($act=='exit_admin'){
	if(empty($_SESSION['admin_username']) or empty($_SESSION['admin_password'])){
		exit(json_encode(array('msg'=>'注销失败!','mode'=>'1')));
	}
	unset($_SESSION['admin_username']);
	unset($_SESSION['admin_password']);
	exit(json_encode(array('msg'=>'注销成功!','mode'=>'2')));
}
if($act=='exit_user'){
	if(empty($_SESSION['user_username']) or empty($_SESSION['user_password'])){
		exit(json_encode(array('msg'=>'注销失败!','mode'=>'1')));
	}
	unset($_SESSION['user_username']);
	unset($_SESSION['user_password']);
	exit(json_encode(array('msg'=>'注销成功!','mode'=>'2')));	
}
if($act=='check_mysql'){
	if(file_exists('skin_config.php')){
		exit(json_encode(array('mode'=>'1','msg'=>'你貌似已经安装过了？请删除skin_config文件后重试')));
	}
	$db_name=htmlspecialchars($_POST['db_name']);//获取数据库名
	$db_host=htmlspecialchars($_POST['db_host']);//获取数据库地址
	$db_port=htmlspecialchars($_POST['db_port']);//获取数据库端口
	$db_username=htmlspecialchars($_POST['db_username']);//获取数据库用户名
	$db_password=htmlspecialchars($_POST['db_password']);//获取数据
	if((empty($db_name) and empty($db_host) and empty($db_port) and empty($db_username)) and empty($db_password)){
		exit(json_encode(array('mode'=>'1','msg'=>'你似乎忘记填了什么东西！')));
	}
	$link=mysqli_connect($db_host, $db_username, $db_password, $db_name, $db_port);
	if(!$link){
		exit(json_encode(array('mode'=>'1','msg'=>'连接失败错误详细如下:'.mysqli_connect_error())));
	}else{
		mysqli_close($link);
		exit(json_encode(array('mode'=>'2','msg'=>'连接数据库成功！')));
	}
}
if($act=='install_table'){
	if(file_exists('skin_config.php')){
		exit(json_encode(array('mode'=>'1','msg'=>'你貌似已经安装过了？请删除skin_config文件后重试')));
	}	
	$admin_username=md5($_POST['admin_username']);//获取管理员用户名
	$admin_password=md5($_POST['admin_password']);//获取管理员密码
	$db_host=$_POST['db_host'];//获取数据库地址
	$db_port=$_POST['db_port'];//获取数据库端口
	$db_username=$_POST['db_username'];//获取数据库用户名
	$db_password=$_POST['db_password'];//获取数据库密码
	$db_name=$_POST['db_name'];//获取数据库名
	$mode=$_POST['mode'];//获取模式
	$db_authme['table']=$_POST['db_authme_table'];
	$db_authme['realname']=$_POST['db_authme_realname'];
	$db_authme['password']=$_POST['db_authme_password'];
	$db_authme['username']=$_POST['db_authme_username'];
	$db_beelogin['table']=$_POST['db_beelogin_table'];
	$db_beelogin['username']=$_POST['db_beelogin_username'];
	$db_beelogin['password']=$_POST['db_beelogin_password'];
	$db_beelogin['password_salt']=$_POST['db_beelogin_paasword_salt'];
	if(empty($mode)){
		exit(json_encode(array('mode'=>'1','msg'=>'你似乎不在状态?')));
	}
	if(((empty($admin_password) or empty($admin_username)) or (empty($db_host) or empty($db_port) or empty($db_name) or empty($db_username))) and empty($db_password)){
		exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了?')));
	}
	switch ($mode) {
		case 'None'://使用自带数据库
			$info=install_table($admin_username, $admin_password, $db_host, $db_port, $db_name, $db_username, $db_password,'none');
		    if($info['act']==FALSE){
		    	exit(json_encode(array('mode'=>'1','msg'=>'似乎出现了这个错误:'.$info['msg'])));
		    }else{
		    	exit(json_encode(array('mode'=>'2','msg'=>'安装成功,并且还返回了一些奇怪的东西哦!<br>'.$info['msg'])));
		    }
			break;
		case 'Beelogin'://使用beelogin数据库
		    if(empty($db_beelogin['table']) or empty($db_beelogin['username']) or empty($db_beelogin['password']) or empty($db_beelogin['password_salt'])){
		    	exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了?')));
		    }
			$info=install_table($admin_username, $admin_password, $db_host, $db_port, $db_name, $db_username, $db_password,'beelogin',$db_beelogin);
		    if($info['act']==FALSE){
		    	exit(json_encode(array('mode'=>'1','msg'=>'似乎出现了这个错误:'.$info['msg'])));
		    }else{
		    	exit(json_encode(array('mode'=>'2','msg'=>'安装成功,并且还返回了一些奇怪的东西哦!<br>'.$info['msg'])));
		    }		
		    break;
		case 'Authme'://使用Authme数据库
		    if(empty($db_authme['table']) or empty($db_authme['realname']) or empty($db_authme['username']) or empty($db_authme['password'])){
		    	exit(json_encode(array('mode'=>'1','msg'=>'你似乎有东西忘记填了?')));
		    }
			$info=install_table($admin_username, $admin_password, $db_host, $db_port, $db_name, $db_username, $db_password,'authme',$db_authme);
		    if($info['act']==FALSE){
		    	exit(json_encode(array('mode'=>'1','msg'=>'似乎出现了这个错误:'.$info['msg'])));
		    }else{
		    	exit(json_encode(array('mode'=>'2','msg'=>'安装成功,并且还返回了一些奇怪的东西哦!<br>'.$info['msg'])));
		    }		
		    break;
		default:
			exit(json_encode(array('mode'=>'1','msg'=>'你似乎状态有点不对劲！')));
			break;
	}
}
if($act=='get_skin_list'){
	$info_sql=config_read();//读入配置
	$mysqli=mysqli_connect($info_sql['db_host'],$info_sql['db_username'], $info_sql['db_password'], $info_sql['db_name'], $info_sql['db_port']);
	exit(json_encode(get_skin_list($mysqli, $_REQUEST['first'], $_REQUEST['last'], $_REQUEST['mode'])));
}
exit(json_encode(array('mode'=>'1','msg'=>'你似乎状态有点不对劲！')));
function install_table($admin_username,$admin_password,$db_host,$db_port,$db_name,$db_username,$db_password,$mode,$config){
	$mysqli=mysqli_connect($db_host, $db_username, $db_password,$db_name, $db_port);//链接数据库
	if(!$mysqli){
		$info['act']=FALSE;
		$info['msg']='Mysqli链接错误:'.mysqli_connect_error();
		return $info;
	}
	$sql='CREATE TABLE skin_config(id int(5) NOT NULL AUTO_INCREMENT,config_id varchar(255),config_contain text,UNIQUE (config_id),PRIMARY KEY (id))';//创建config表
	$result=mysqli_query($mysqli, $sql);
	if($result){
		$info['msg']='[Oneskin]skin_config表创建成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]skin_config 创建失败或已存在!"错误信息如下:'.mysqli_error($mysqli).'<br>';
	}
	$sql="CREATE TABLE skinme(user varchar(45),pass varchar(45),email varchar(100),skinmd5 varchar(32),apemd5 varchar(32),list_skin text,list_ape text)";
	$result=mysqli_query($mysqli, $sql);
	if($result){
		$info['msg']=$info['msg'].'[Oneskin]skinme表创建成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]skinme创建失败或已存在!"错误信息如下:'.mysqli_error($mysqli).'<br>';
	}
	$sql = "CREATE TABLE skin_email(user varchar(255),email varchar(255),time varchar(255),code varchar(10))";
	$result=mysqli_query($mysqli, $sql);
	if($result){
		$info['msg']=$info['msg'].'[Oneskin]skin_email表创建成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]skin_email创建失败或已存在!"错误信息如下:'.mysqli_error($mysqli).'<br>';
	}	
	$sql = "CREATE TABLE skinlink(id int(5) NOT NULL AUTO_INCREMENT,md5 varchar(32),skin varchar(255),name varchar(255),PRIMARY KEY (id))";
	$result=mysqli_query($mysqli, $sql);
	if($result){
		$info['msg']=$info['msg'].'[Oneskin]skinlink表创建成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]skinlink创建失败或已存在!"错误信息如下:'.mysqli_error($mysqli).'<br>';
	}
	$sql = "CREATE TABLE apelink(id int(5) NOT NULL AUTO_INCREMENT,md5 varchar(32),ape varchar(255),name varchar(255),PRIMARY KEY (id))";
	$result=mysqli_query($mysqli, $sql);
	if($result){
		$info['msg']=$info['msg'].'[Oneskin]apelink表创建成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]apelink创建失败或已存在!"错误信息如下:'.mysqli_error($mysqli).'<br>';
	}
	//创建数据表格
	if(mkdir('skin')){
		$info['msg']=$info['msg'].'[Oneskin]创建Skin文件夹成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]创建Skin文件夹失败或已存在!<br>';
	}
	if(mkdir('ape')){
		$info['msg']=$info['msg'].'[Oneskin]创建Ape文件夹成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]创建Ape文件夹失败或已存在!<br>';
	}
	if(mkdir('show_skin')){
		$info['msg']=$info['msg'].'[Oneskin]创建show_skin文件夹成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]创建show_skin文件夹失败或已存在!<br>';
	}
	if(mkdir('show_ape')){
		$info['msg']=$info['msg'].'[Oneskin]创建show_ape文件夹成功!<br>';
	}else{
		$info['msg']=$info['msg'].'[Oneskin]创建show_ape文件夹失败或已存在!<br>';
	}
	//创建文件夹
	$config['admin_username']=$admin_username;
	$config['admin_password']=$admin_password;
	$config['db_name']=$db_name;
	$config['db_host']=$db_host;
	$config['db_port']=$db_port;
	$config['db_username']=$db_username;
	$config['db_password']=$db_password;
	$config['regular_username']='/^[a-zA-Z0-9_]{3,16}$/';
	$config['regular_password']=base64_encode('/^[\x21-\x7E]{6,22}$/');
	$config['regular_email']=base64_encode('/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/');
	//基础正则
	
	//存配置部分
	if($mode=='beelogin'){//beelogin状态
		$config['mode']='beelogin';
	}
	if($mode=='authme'){//Authme状态
		$config['mode']='authme';
	}
	if($mode=='none'){//无状态
		$config['mode']='none';
	}
	$info['act']=TRUE;
	writefile("skin_config.php", "<?php ".'$sql_config'."='".base64_encode(json_encode($config))."'; ?>");
	return $info;
}
function write_table_config($mysqli,$config_name,$config_content){
	$sql='INSERT INTO skin_config (config_id,config_contain) VALUES (?,?)';//sql语句
	$stmt=mysqli_prepare($mysqli, $sql);//置入指令
	mysqli_stmt_bind_param($stmt, "ss", $config_name,$config_content);
	if(mysqli_stmt_execute($stmt)){
		mysqli_stmt_close($stmt);//释放句柄
		return TRUE;
	}else{
		mysqli_stmt_close($stmt);//释放句柄
		return FALSE;
	}
}
function skin_preview($name,$id,$gg,$yb=true){
if(!empty($id))$skin=getid(false,$id);else if(!empty($name))$skin=nameget($name,false);else if(!empty($gg))$skin=$gg;
if(!$skin)$skin=topng(base64_decode($DefaultSkin));
if(!$skin)return false;
$x=imagesx($skin);
$y=imagesy($skin);
$bmskin=imagecreatetruecolor($x,$y);
imagesavealpha($bmskin,true);
$skins=imagecolorallocatealpha($bmskin,255,255,255,127);
imagefill($bmskin,0,0,$skins);
$x=imagecopyresampled($bmskin,$skin,0,0,($x-1),0,$x,$y,0-$x,$y);
$s=imagesy($skin)/32;
$pic=imagecreatetruecolor(($yb?18:36)*$s,32*$s);
imagesavealpha($pic,true);
$skins=imagecolorallocatealpha($pic,255,255,255,127);
imagefill($pic,0,0,$skins);
imagecopy($pic,$skin,4*$s,0,8*$s,8*$s,8*$s,8*$s);
imagecopy($pic,$skin,4*$s,0,40*$s,8*$s,8*$s,8*$s);
imagecopy($pic,$skin,0,8*$s,44*$s,20*$s,4*$s,12*$s);
imagecopy($pic,$skin,4*$s,8*$s,20*$s,20*$s,8*$s,12*$s);
imagecopy($pic,$skin,4*$s,20*$s,4*$s,20*$s,4*$s,12*$s);
imagecopy($pic,$bmskin,12*$s,8*$s,16*$s,20*$s,4*$s,12*$s);
imagecopy($pic,$bmskin,8*$s,20*$s,56*$s,20*$s,4*$s,12*$s);
if(empty($yb)){
	imagecopy($pic,$skin,24*$s,0,24*$s,8*$s,8*$s,8*$s);
	imagecopy($pic,$skin,24*$s,0,56*$s,8*$s,8*$s,8*$s);
	imagecopy($pic,$skin,32*$s,8*$s,52*$s,20*$s,4*$s,12*$s);
	imagecopy($pic,$skin,24*$s,8*$s,32*$s,20*$s,8*$s,12*$s);
	imagecopy($pic,$skin,28*$s,20*$s,12*$s,20*$s,4*$s,12*$s);
	imagecopy($pic,$bmskin,20*$s,8*$s,8*$s,20*$s,4*$s,12*$s);
	imagecopy($pic,$bmskin,24*$s,20*$s,48*$s,20*$s,4*$s,12*$s);
}
imagedestroy($skin);
imagedestroy($bmskin);
$img=imagecreatetruecolor($yb?59:117,105);
imagesavealpha($img,true);
imagefill($img,0,0,$skins);
if (imagesx($img) >= imagesx($pic)) {
imagecopyresized($img,$pic,0,0,0,0,imagesx($img),imagesy($img),imagesx($pic),imagesy($pic));
    } else {
imagecopyresampled($img,$pic,0,0,0,0,imagesx($img),imagesy($img),imagesx($pic),imagesy($pic));
}
return $img;
}
function skin_18to17($skin){
  $arr=getimagesize($skin);
  if(!$arr)return false;
  if($arr[0]!=$arr[1]||$arr[0]<64)return false;
  $size=$arr[0];
  $img=imagecreatetruecolor($size,$size/2);
  imagesavealpha($img,true);
  $c=imagecolorallocatealpha($img,255,255,255,127);
  imagealphablending($img,false);
  imagefill($img,0,0,$c);
  imagesavealpha($img,true);
  $pic=imagecreatefrompng($skin);
  imagecopy($img,$pic,0,0,0,0,$size,$size/2);
  imagedestroy($pic);
  if($img!=null)return $img;else return false;
}
function skin_17to18($skin){
  $arr=getimagesize($skin);
  if(!$arr)return false;
  if($arr[0]!=$arr[1]*2||$arr[0]<64)return false;
  $size=$arr[0];
  $img=imagecreatetruecolor($size,$size);
  imagesavealpha($img,true);
  $c=imagecolorallocatealpha($img,255,255,255,127);
  imagealphablending($img,false);
  imagefill($img,0,0,$c);
  imagesavealpha($img,true);
  $pic=imagecreatefrompng($skin);
  imagecopy($img,$pic,0,0,0,0,$size,$size/2);
  $size=$size/4;
  imagecopy($img,$pic,$size,$size*3,0,$size,$size,$size);
  imagecopy($img,$pic,$size*2,$size*3,$size/2*5,$size,$size,$size);
  imagedestroy($pic);
  if($img!=null)return $img;else return false;
}
function topng($img){
    if(!$img)return false;
    $ls=sys_get_temp_dir()."/".rand(1000000,999999999);
    if(!file_put_contents($ls,$img))return false;
    $skin=imagecreatefrompng($ls);
    imagesavealpha($skin,true);
    unlink($ls);
    if(empty($skin))return false;else return $skin;
}
function get_skin_list($mysqli,$first,$last,$mode){
	if(empty($mysqli)){
		$info['mode']='1';
		$info['msg']='mysqli链接失败?';
		return $info;
	}
	if(empty($mode)){
		$info['mode']='1';
		$info['msg']='你有东西忘记填写了!';
		return $info;		
	}
	if(empty($last)){
		$last=$first;
	}else{
		$first=$last;
	}
	if($mode!='ape' and $mode!='skin'){
		$info['mode']='1';
		$info['msg']='模式有误!';
		return $info;		
	}
	$last=intval($last);
	$first=intval($first);
	$num_1 = ($last - $first);
	$num_2 = ($first - $last);
	if(($num_1>17) or ($num_2<-17)){
		$skin_list['mode']='1';
		$skin_list['msg']='数组错误！';
		return $skin_list;		
	}
	if($mode=='skin'){
		$sql='SELECT * FROM skinlink order by id desc limit ?,16';
		$sql_first='SELECT * FROM skinlink order by id limit 1';
	}else{
		$sql='SELECT * FROM apelink order by id desc limit ?,16';
		$sql_first='SELECT * FROM apelink order by id limit 1';
	}
	$stmt_first = mysqli_prepare($mysqli, $sql_first);
	if(!mysqli_stmt_execute($stmt_first)){
		$skin_list['mode']='1';
		$skin_list['msg']='[first]执行失败';
		return $skin_list;		
	}
	mysqli_stmt_bind_result($stmt_first,$id,$skin_md5,$skin_link,$skin_name);
	mysqli_stmt_fetch($stmt_first);
	mysqli_stmt_close($stmt_first);
	//获取第一个皮肤id
	
	$stmt = mysqli_prepare($mysqli, $sql);
	mysqli_stmt_bind_param($stmt, "i", $first);
	if(!mysqli_stmt_execute($stmt)){
		$skin_list['mode']='1';
		$skin_list['msg']='执行失败';
		return $skin_list;		
	}
	mysqli_stmt_bind_result($stmt,$skin_id,$skin_md5,$skin_link,$skin_name);
	$skin_list['skin_list']=array("");
	$i=0;
    while(mysqli_stmt_fetch($stmt)){
    	$i=$i+1;
    	$str_json=object_array(json_decode($skin_name));
		$skin_arr['skin_id'] = $skin_id;
		$skin_arr['skin_md5'] = $skin_md5;
		$skin_arr['skin_link'] = $skin_link;
		$skin_arr['skin_time'] = date("Y-m-d H:i:s",$str_json['skin_time']);
		$skin_arr['skin_updata_user'] = $str_json['skin_updata_user'];
		$skin_arr['skin_name'] = base64_decode($str_json['skin_name']);
		array_push($skin_list['skin_list'],$skin_arr);
		if($id==$skin_id){
			$skin_list['num']=$i;
			$skin_list['mode']='4';
			$skin_list['msg']='似乎没有更多了！';
			mysqli_stmt_close($stmt);
			return $skin_list;			
			//到达最前事件
		}
    }
	mysqli_stmt_close($stmt);
	if($i==0){
		$skin_list['mode']='3';
		$skin_list['msg']='似乎没有更多了！';
		return $skin_list;
	}
	if($i<15){
		$skin_list['mode']='4';
	}else{
		$skin_list['mode']='2';
	}
	$skin_list['num']=$i;
	$skin_list['msg']='获取成功!';
	$skin_list['first']=$last+16;
	$skin_list['last']=$last-16;
	return $skin_list;
}
?>