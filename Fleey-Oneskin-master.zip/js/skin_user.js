$("#file_pic").change(function(){
    var objUrl = getObjectURL(this.files[0]) ;
    if (objUrl) {
        $("#skin_img").attr("src", objUrl) ;
    }
});
function list(){
    $("select.image-picker").imagepicker({
        hide_select:true
    });
}
//上传图片预览
window.onload=function(){ 
list(); 
} 
var act_mode='';
function load_skin_list(){
    $.ajax({
        type:"post",
        url:"../skin_ajax.php",
        data:{
            act:'get_warehouse_list',
            groups:'user'
        },
        dataType:'json',
        success:function(data){
            if(data.list_skin_mode=='1'){
                document.getElementById('skin_skin').innerHTML='<blockquote><p class="am-text-sm am-text-truncate am-sans-serif">你仓库貌似没有皮肤。赶紧塞点进去吧！</p></blockquote>';
            }else{
                var skin_select=document.getElementById('skin_skin');
                var skin_list=data.list_skin;//获取皮肤列表
                var str_skin_list=skin_list.replace(/\*/g,"");//过滤字符串
                var arr_skin_list=str_skin_list.split(',');//分割字符串
                var skin_skin_html='';
                for(i=0;i<arr_skin_list.length-1;i++){
                    skin_skin_html+='<option data-img-src="../skin_ajax.php?act=preview&mode=skin&groups=user&id='+arr_skin_list[i]+'" value="'+arr_skin_list[i]+'">'+arr_skin_list[i]+'</option>'
                }
                skin_select.innerHTML='<select class="image-picker" id="skin_select">'+skin_skin_html+'</select>';
                //有皮肤状态
            }
            if(data.list_ape_mode=='1'){
                document.getElementById('skin_ape').innerHTML='<blockquote><p class="am-text-sm am-text-truncate am-sans-serif">你仓库貌似没有披风。赶紧塞点进去吧！</p></blockquote>';
            }else{
                var ape_select=document.getElementById('skin_ape');
                var ape_list=data.list_ape;//获取披风列表
                var str_ape_list=ape_list.replace(/\*/g,"");//过滤字符串
                var arr_ape_list=str_ape_list.split(',');//分割字符串	
                var skin_ape_html='';
                for(i=0;i<arr_ape_list.length-1;i++){
                    skin_ape_html+='<option data-img-src="../skin_ajax.php?act=preview&mode=ape&groups=user&id='+arr_ape_list[i]+'" value="'+arr_ape_list[i]+'">'+arr_ape_list[i]+'</option>'
                }
                ape_select.innerHTML='<select class="image-picker" id="ape_select">'+skin_ape_html+'</select>';	
                //有披风状态
            }
        }
    });
}
$(document).ready(function(){
    load_skin_list();
    preview_skin();
    //开始排列皮肤
});
function getObjectURL(file) {
    var url = null ; 
    if (window.createObjectURL!=undefined) { // basic
        url = window.createObjectURL(file) ;
    } else if (window.URL!=undefined) { // mozilla(firefox)
        url = window.URL.createObjectURL(file) ;
    } else if (window.webkitURL!=undefined) { // webkit or chrome
        url = window.webkitURL.createObjectURL(file) ;
    }
    return url ;
}
function exit_user(){
  	$.ajax({
  		type:"post",
  		url:"../skin_ajax.php",
  		data:{
  			act:'exit_user'
  		},
  		dataType:'json',
  		success:function(data){
        	if(data.mode=='1'){
        		$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
        	}
        	if(data.mode=='2'){
        		$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
        		setTimeout('window.location.href="../index.php"',2000);
        	}
  		}
  	});
}
var mode='';
$('#skin_warehouse').find('a').on('opened.tabs.amui', function(e) {
  mode=$(this).text();
})
  $("#updata_pic_button").click(function(){
  	var button_updata =$(this);
  	button_updata.button('loading');
  	var mode = document.getElementsByName("mode");
    for(var i=0; i<2; i ++){
        if(mode[i].checked){
           var mode = mode[i].value;
           var c = 1;
        }
    }
    if(c!=1){
    	$.toaster({ priority : 'am-alert-warning', title : '错误', message :'你似乎还没有选中呢！'});
    	button_updata.button('reset');
    	return false;
    }
    //逻辑得出那个选中了
    $.ajaxFileUpload({
        url:'../skin_ajax.php',//处理图片脚本
        secureuri :false,
        async : false,
        data:{
        	act:'updata_skin',
        	mode:mode,
        	groups:'user',
        	skin_name:document.getElementById('skin_name').value
        },
        fileElementId :'file_pic',//file控件id
        dataType : 'json',
        success : function (data, status){
        	if(data.mode=='1'){
        		document.getElementById('skin_img').src='../images/bg[4].jpg';
        		reload_updata();
        		$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
        	}
        	if(data.mode=='2'){
        		load_skin_list();
        		document.getElementById('skin_img').src='../images/bg[4].jpg';
        		reload_updata();
        		$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
        		$('#updata_pic').modal('close');
        	}
        	button_updata.button('reset');
        	setTimeout('list()',500);
        },
        error:function(data, status, e){
        	load_skin_list();
        	document.getElementById('skin_img').src='../images/bg[4].jpg';
        	reload_updata();
        	$.toaster({ priority : 'am-alert-success', title : '错误:', message :'未知错误'});
        	$('#updata_pic').modal('close');
        	button_updata.button('reset');
        	setTimeout('list()',500);        	
        }
    });
    return false;
  });
  $('#skin_info_button').click(function(){
  	$('#skin_info').modal('open');
  	if(mode!='披风'){
  		document.getElementById('set_skin').innerText='设置为主皮肤';
  		act_mode='skin';
  	}else{
  		document.getElementById('set_skin').innerText='设置为主披风';
  		act_mode='ape';
  	}
  	$.ajax({
  		type:"post",
  		url:"../skin_ajax.php",
  		data:{
  			act:'get_skin_info',
  			groups:'user',
  			mode:'select_id',
  			select_mode:act_mode,
  			id:get_id(act_mode)
  		},
  		dataType:'json',
  		success:function(data){
  			if(data.mode=='1'){
  				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
  			}
  			if(data.mode=='2'){
  				document.getElementById('skin_info_img').src='../'+data.skin_link;
  				document.getElementById('skin_info_name').value=data.skin_name;
  				document.getElementById('skin_md5').value=data.skin_md5;
  				document.getElementById('skin_info_updata_time').value=data.skin_time;
  				document.getElementById('skin_info_updata_name').value=data.skin_updata_user;
  				document.getElementById('set_skin').value=data.skin_id;
  				document.getElementById('del_skin').value=data.skin_id;
  				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
  			}
  		}
  	});
  });
  $('#del_skin').click(function(){
  	del_skin(get_id(act_mode),act_mode);
  	$('#skin_info').modal('close');
  });
  $('#set_skin').click(function(){
  	set_skin(get_id(act_mode),act_mode);
  	preview_skin();
  	$('#skin_info').modal('close');
  }); 
function reload_updata(){
    document.getElementById('updata_file').innerHTML='<input id="file_pic" type="file" name="file_pic" multiple>';
}
function set_skin(id,mode){
    $.ajax({
        type:"post",
        url:"../skin_ajax.php",
        data:{
            act:'set_skin',
            groups:'user',
            id:id,
            mode:mode
        },
        dataType:'json',
        success:function(data){
  			if(data.mode=='1'){
  				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
  			}
  			if(data.mode=='2'){
  				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
  			}
        }
    });
}
function del_skin(id,mode){
    $.ajax({
        type:"post",
        url:"../skin_ajax.php",
        data:{
            act:'del_skin',
            groups:'user',
            id:id,
            mode:mode
        },
        dataType:'json',
        success:function(data){
  			if(data.mode=='1'){
  				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
  			}
  			if(data.mode=='2'){
  				load_skin_list();
  				setTimeout('list()',1000);
  				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
  			}
        }
    });
}
function get_id(act){
    if(act=="skin"){
        var select = document.getElementById("skin_select");
    }
    if(act=="ape"){
        var select = document.getElementById("ape_select");
    }
    var index = select.selectedIndex;
    if(select.innerText==''){
        $('#skin_info').modal('close');
        return false;
    }
    var value = select.options[index].value;
    return value;
}
