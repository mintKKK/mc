var mode='';
$('#skin_list').find('a').on('opened.tabs.amui', function(e) {
  mode=$(this).text();
  if(mode=='皮肤'){
  	next('skin',1);
  	//皮肤状态
  }else{
  	next('ape',1);
  	//皮风状态
  }
})
function newcode(){
	var Rand = Math.random();
	document.getElementById('img_code_1').setAttribute('src','../skin_code.php?rank='+Rand);
}
function admin_login(){
	$('#ajax_login').button('loading');
	$.ajax({
		type:"post",
		url:"skin_admin.php",
		data:{
			act:'admin_login',
			login_username:document.getElementById('login_username').value,
			login_password:document.getElementById('login_password').value,
			login_code:document.getElementById('login_code').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='1'){
				newcode();
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
				setTimeout('myrefresh()',2000);
			}	
			$('#ajax_login').button('reset');
		}
	});
}
document.onkeydown=function(event){
var e = event || window.event || arguments.callee.caller.arguments[0];
if(e && e.keyCode==13){ // enter 键
admin_login();
}
};
function myrefresh(){
	window.location.reload();
}
function title(title,title_small){
	document.getElementById('info_title').innerText=title;
	document.getElementById('info_title_small').innerText=title_small;
}
function jump(id){
	document.getElementById('admin_body').setAttribute('style','display:block;');
	document.getElementById('b0').removeAttribute('style');
	document.getElementById('b1').removeAttribute('style');
	document.getElementById('b3').removeAttribute('style');
	document.getElementById('b4').removeAttribute('style');
	document.getElementById('b5').removeAttribute('style');
	document.getElementById('b6').removeAttribute('style');
	document.getElementById('skin_list_div').setAttribute('style','display: none;');
	switch (id){
		case 0:
		document.getElementById('b0').setAttribute('style','background: #ecf0f1');
		load_index();
			break;
		case 1:
		document.getElementById('b1').setAttribute('style','background: #ecf0f1');
		ajax_admin('admin_change_password');
			break;
		case 3:
		document.getElementById('b3').setAttribute('style','background: #ecf0f1');
		ajax_admin('admin_player_list');
			break;
		case 4:
		document.getElementById('b4').setAttribute('style','background: #ecf0f1');
		document.getElementById('admin_body').setAttribute('style','display: none;');
		document.getElementById('skin_list_div').setAttribute('style','display: block;');
		next('skin',1);
			break;
		case 5:
		document.getElementById('b5').setAttribute('style','background: #ecf0f1');//配置
		var progress = $.AMUI.progress.configure({ parent: '.admin-content' });
		progress.start();
		$.ajax({
			type:"post",
			url:"../skin_ajax.php",
			data:{
				groups:'admin',
				act:'admin_config'
			},
			dataType:'text',
			success:function(data){
				document.getElementById('admin_body').innerHTML=data;
				progress.done();
			}
		});
			break;
		case 6:
		document.getElementById('b6').setAttribute('style','background: #ecf0f1');//注销
		$.ajax({
			type:"post",
			url:"../skin_ajax.php",
			data:{
				act:'exit_admin'
			},
			dataType:'json',
			success:function(data){
				if(data.mode=='2'){
					$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
					setTimeout('myrefresh()',2000);
				}else{
					$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
				}
			}
		});
			break;
		default:
		return;
			break;
	}
}
function title_config_save(){
	$.ajax({
		type:"post",
		url:"../skin_ajax.php",
		data:{
			groups:'admin',
			act:'save_config_title',			
			title:document.getElementById('title_name').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
		}
	});
}
function save_config_db(){
	$('#save_config_db').button('loading');
	$.ajax({
		type:"post",
		url:"../skin_ajax.php",
		data:{
			groups:'admin',
			act:'save_config_db',
			db_host:document.getElementById('db_host').value,
			db_port:document.getElementById('db_port').value,
			db_username:document.getElementById('db_username').value,
			db_password:document.getElementById('db_password').value,
			db_name:document.getElementById('db_name').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}		
			$('#save_config_db').button('reset');
		}
	});
}
function smtp_get_code(){
	$('#smtp_get_code').button('loading');
	var select = document.getElementById('smtp_mode');
	var index = select.selectedIndex;
	$.ajax({
		type:"post",
		url:"../skin_ajax.php",
		data:{
			groups:'admin',
			act:'smtp_get_code',
			send_username:document.getElementById('smtp_send_code').value,
			smtp_host:document.getElementById('smtp_host').value,
			smtp_port:document.getElementById('smtp_port').value,
			smtp_username:document.getElementById('smtp_username').value,
			smtp_password:document.getElementById('smtp_password').value,
			smtp_ssl:select.options[index].value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}			
			$('#smtp_get_code').button('reset');
		}
	});
}
function smtp_config_save(){
	$('#smtp_get_code').button('loading');
	var select = document.getElementById('smtp_mode');
	var index = select.selectedIndex;	
	$.ajax({
		type:"post",
		url:"../skin_ajax.php",
		data:{
			groups:'admin',
			act:'save_config_smtp',
			smtp_host:document.getElementById('smtp_host').value,
			smtp_port:document.getElementById('smtp_port').value,
			smtp_username:document.getElementById('smtp_username').value,
			smtp_password:document.getElementById('smtp_password').value,
			smtp_ssl:select.options[index].value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}			
			$('#smtp_get_code').button('reset');
		}
	});	
}
function load_index(){
		var progress = $.AMUI.progress.configure({ parent: '.admin-content' });
		progress.start();
		$.ajax({
			type:"post",
			url:"../skin_ajax.php",
			data:{
				groups:'admin',
				act:'admin_index'
			},
			dataType:'text',
			success:function(data){
				document.getElementById('admin_body').innerHTML=data;
				progress.done();
			}
		});
}
window.onload=function(){ 
load_index();
}
function ajax_admin(act){
		var progress = $.AMUI.progress.configure({ parent: '.admin-content' });
		progress.start();
		$.ajax({
			type:"post",
			url:"../skin_ajax.php",
			data:{
				groups:'admin',
				act:act
			},
			dataType:'text',
			success:function(data){
				document.getElementById('admin_body').innerHTML=data;
				progress.done();
			}
		});	
}
function change_password(){
		var progress = $.AMUI.progress.configure({ parent: '.admin-content' });
		progress.start();
		$.ajax({
			type:"post",
			url:"skin_admin.php",
			data:{
				groups:'admin',
				act:'change_password',
				old_admin_password:document.getElementById('old_admin_password').value,
				new_admin_password:document.getElementById('new_admin_password').value,
				new_again_admin_password:document.getElementById('again_new_admin_password').value
			},
			dataType:'json',
			success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
				setTimeout('myrefresh()',1000);
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}		
				progress.done();
			}
		});	
}
function user_info(username){
	$('#find_passowrd_modal').modal('open');
	document.getElementById('find_title').innerText=username;	
}
function change_user(){
	$('#ajax_change').button('loading');
	$.ajax({
		type:"post",
		url:"skin_admin.php",
		data:{
			act:'change_user_password',
			groups:'admin',
			user_username:document.getElementById('find_title').innerText,
			user_password:document.getElementById('user_new_password').value,
			user_again_password:document.getElementById('user_new_again_password').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
				$('#find_passowrd_modal').modal('close');
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			$('#ajax_change').button('reset');
		}
	});
}
function del_user(username){
	$.ajax({
		type:"post",
		url:"skin_admin.php",
		data:{
			act:'del_user',
			groups:'admin',
			user_username:username
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
				ajax_admin('admin_player_list');
			}else{
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}			
		}
	});
}
function next(mode, page,last) {
	if (mode == 'skin') {
		var table = document.getElementById('skin_table');
	}
	if (mode == 'ape') {
		var table = document.getElementById('ape_table');
	}
	$.ajax({
		type: "POST",
		url: "skin_admin.php",
		data: {
			act: 'get_skin_list',
			mode:mode,
			first: page,
			last:last
		},
		dataType: 'json',
		success: function(data) {
			if (data.mode == '2' || data.mode=='4') {
				var info = '';
				var name = '';
				for (var i = 1; i <= data.num; i++) {
					info = info + '<tr><td>' + data.skin_list[i].skin_id + '</td><td>' + data.skin_list[i].skin_md5 + '</td><td><img class="am-radius" alt="140*140" src="../' + data.skin_list[i].skin_link + '" width="140" height="140" /></td><td><button class="am-btn am-btn-danger" onclick="delete_skin(' + "'"+data.skin_list[i].skin_id + "'"+','+"'"+mode+"'"+')" type="button">删除</button><a href="../' + data.skin_list[i].skin_link + '" class="am-btn am-btn-primary">预览</a></td></tr>';
				}
				table.innerHTML = info;
				var last = data.last + 1;
				document.getElementById('next_up').setAttribute('onclick', 'next("'+mode+'",' + data.last+')');
				document.getElementById('next_down').setAttribute('onclick', 'next("'+mode+'",' + data.first+')');
				$.toaster({
					priority: 'am-alert-success',
					title: '成功',
					message: data.msg
				});
			} 
			
			if(data.mode=='1' || data.mode=='3'){
				$.toaster({
					priority: 'am-alert-warning',
					title: '错误',
					message: data.msg
				});
				table.innerHTML = '</br><blockquote>错误信息：' + data.msg + '</blockquote>';
			}
		}
	});
}
function delete_skin(skin_id,mode_skin){
    $.ajax({
        type:"POST",
        url:"skin_admin.php",
        data:{groups:'admin',act:'del_skin',skin_id:skin_id,mode:mode_skin},
        dataType:'json',
        success:function (data){
            if(data.mode=='2'){
            	$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
            }else{
            	$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
            }
        }
    });
}
