$(function() {
	var $selected = $('#select_mode');
	$selected.on('change', function() {
		document.getElementById('Beelogin').setAttribute('style','display: none;');
		document.getElementById('Authme').setAttribute('style','display: none;');
		document.getElementById('next_3').setAttribute('style','display: block;');
		switch ($(this).val()){
			case 'None':
				break;
			case 'Beelogin':
			document.getElementById('Beelogin').setAttribute('style','display: block;');
			    break;
			case 'Authme':
			document.getElementById('Authme').setAttribute('style','display: block;');
			    break;
			default:
			return;
				break;
		}
		document.getElementById('install').setAttribute('name',$(this).val());
	});
});
function next(id){
	document.getElementById('a1').setAttribute('style','display: none;');
	document.getElementById('a2').setAttribute('style','display: none;');
	document.getElementById('a3').setAttribute('style','display: none;');
	document.getElementById('a4').setAttribute('style','display: none;')
	var title=document.getElementById('panel_title');
	if(id==2){
		title.innerText='安装第二步';
		document.getElementById('a2').setAttribute('style','display: block;');
	}
	if(id==3){
		title.innerText='安装第三步';
		document.getElementById('a3').setAttribute('style','display: block;');
	}
	if(id==4){
		title.innerText='安装第四步';
		db_install(document.getElementById('install').getAttribute('name'));
	}
}
function check_db(){
	var progress = $.AMUI.progress;
	progress.start();
	$.ajax({
		type:"post",
		url:"../skin_ajax.php",
		data:{
			act:'check_mysql',
			db_port:document.getElementById('db_port').value,
			db_host:document.getElementById('db_host').value,
			db_username:document.getElementById('db_username').value,
			db_password:document.getElementById('db_password').value,
			db_name:document.getElementById('db_name').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='1'){
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}else{
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
				document.getElementById('select_div').setAttribute('style','display: block;');
				document.getElementById('check_db').setAttribute('style','display: none;');
				document.getElementById('next_3').setAttribute('style','display: block;');
			}
			progress.done();
		}
	});
}
function db_install(mode){
	if(mode==undefined){
		mode='None';
	}
		$.ajax({
			type:"post",
			url:"../skin_ajax.php",
			data:{
				mode:mode,
				act:'install_table',
				admin_username:document.getElementById('admin_username').value,
				admin_password:document.getElementById('admin_password').value,
				db_name:document.getElementById('db_name').value,
				db_host:document.getElementById('db_host').value,
				db_port:document.getElementById('db_port').value,
				db_username:document.getElementById('db_username').value,
				db_password:document.getElementById('db_password').value,
				db_authme_table:document.getElementById('db_authme_table').value,
				db_authme_realname:document.getElementById('db_authme_realname').value,
				db_authme_username:document.getElementById('db_authme_username').value,
				db_authme_password:document.getElementById('db_authme_passworld').value,
				db_beelogin_table:document.getElementById('db_beelogin_table').value,
				db_beelogin_username:document.getElementById('db_beelogin_username').value,
				db_beelogin_password:document.getElementById('db_beelogin_password').value,
				db_beelogin_paasword_salt:document.getElementById('db_beelogin_password_salt').value
			},
			dataType:'json',
			success:function(data){
				var title=document.getElementById('panel_title');
				if(data.mode=='1'){
					title.innerText='似乎出现了个错误,将为回滚到上两步。';
					document.getElementById('msg').innerHTML=data.msg;
					document.getElementById('end').innerText='点击我回滚到上两步';
					document.getElementById('end').setAttribute('onclick','next(2)');
				}
				if(data.mode=='2'){
					title.innerText='似乎已经安装成功了哟~';
					document.getElementById('msg').innerHTML=data.msg;
					document.getElementById('end').innerText='点击我进行转跳到主页面';
					document.getElementById('end').setAttribute('onclick',"window.location.href='../index.php';");
				}
				document.getElementById('a4').setAttribute('style','display: block;');
			}
		});
}
