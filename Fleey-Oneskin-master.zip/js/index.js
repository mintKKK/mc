var mode='';
$('#pane_body').find('a').on('opened.tabs.amui', function(e) {
  mode=$(this).text();
})
function login(){
$('#ajax_login').button('loading');
	$.ajax({
		type:"Post",
		url:"skin_user/skin_register_login.php",
		data:{
			act:'login',
			code:document.getElementById('login_code').value,
			login_username:document.getElementById('login_username').value,
			login_password:document.getElementById('login_password').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='1'){
				newcode();
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
				setTimeout('myrefresh()',2000);
			}
			if(data.mode=='3'){
				newcode();
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
				document.getElementById('code').setAttribute('style','display: block;');
			}
			$('#ajax_login').button('reset');
		}
	});
}
document.onkeydown=function(event){
var e = event || window.event || arguments.callee.caller.arguments[0];
if(e && e.keyCode==13){ // enter 键
switch (mode){
	case '登录':
	login();
	break;
		break;
	case '注册':
	register();
	break;
	case '找回密码':
	send_email();
	break;
	default:
	login();
		break;
}
}
};
function myrefresh(){
	window.location.href='skin_user/index.php';
}
function newcode(){
	var Rand = Math.random();
	document.getElementById('img_code_1').setAttribute('src','skin_code.php?rank='+Rand);
	document.getElementById('img_code_2').setAttribute('src','skin_code.php?rank='+Rand);
	document.getElementById('img_code_3').setAttribute('src','skin_code.php?rank='+Rand);
}
function check_username(){
	var progress = $.AMUI.progress;
	progress.start();
	$.ajax({
		type:"post",
		url:"skin_user/skin_register_login.php",
		data:{
			act:'check_username',
			check_username:document.getElementById('register_username').value
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='1'){
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}
			progress.done();
		}
	});
}
function register(){
	var progress = $.AMUI.progress;
	progress.start();
	$("#register_button").button('loading');
	$.ajax({
		type:"post",
		url:"skin_user/skin_register_login.php",
		data:{
			act:'register',
			register_username:document.getElementById('register_username').value,
			register_password:document.getElementById('register_password').value,
			register_email:document.getElementById('register_email').value,
			register_code:document.getElementById('register_code').value
		},
		dataType:'json',
		success:function(data){
			newcode();
			$("#register_button").button('reset');
			if(data.mode=='1'){
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}
			progress.done();
		}
	});	
}
function send_email(){
	var progress = $.AMUI.progress;
	progress.start();
	$("#find_password_button").button('loading');
	$.ajax({
		type:"post",
		url:"skin_user/skin_register_login.php",
		data:{
			act:'find_password',
			find_password_username:document.getElementById('find_password_username').value,
			find_password_email:document.getElementById('find_password_email').value,
			code:document.getElementById('find_password_code').value
		},
		dataType:'json',
		success:function(data){
		    $("#register_button").button('reset');
			newcode();
			if(data.mode=='1'){
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			if(data.mode=='2'){
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}
			progress.done();
		}
	});		
}
