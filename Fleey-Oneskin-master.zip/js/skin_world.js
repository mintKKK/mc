function load_skin_list(mode,first,last){
	$.ajax({
		type:"post",
		url:"skin_ajax.php",
		data:{
			act:'get_skin_list',
			mode:mode,
			first:first,
			last:last
		},
		dataType:'json',
		success:function(data){
			if(data.mode=='1'){
				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
			}
			if(data.mode=='2'||data.mode=='4'){
				if(mode=='skin'){
					var select_skin=document.getElementById('skin_select');
					document.getElementById('skin_down').setAttribute('onclick','load_skin_list('+"'skin',"+data.first+')')
					document.getElementById('skin_up').setAttribute('onclick','load_skin_list('+"'skin',"+data.last+')');
				}
				if(mode=='ape'){
					var select_skin=document.getElementById('ape_select');
					document.getElementById('ape_down').setAttribute('onclick','load_skin_list('+"'ape',"+data.first+')')
					document.getElementById('ape_up').setAttribute('onclick','load_skin_list('+"'ape',"+data.last+')');
				}
				var skin_skin_html ='';
				for(i=1;i<data.num+1;i++){
					if(mode=='skin'){
						skin_skin_html+='<option data-img-src="skin_ajax.php?act=preview&mode=skin&groups=user&id='+data.skin_list[i].skin_id+'" value="'+data.skin_list[i].skin_id+'">'+data.skin_list[i].skin_id+'</option>';
					}else{
						skin_skin_html+='<option data-img-src="skin_ajax.php?act=preview&mode=ape&groups=user&id='+data.skin_list[i].skin_id+'" value="'+data.skin_list[i].skin_id+'">'+data.skin_list[i].skin_id+'</option>';
					}
				}
				select_skin.innerHTML='<select class="image-picker" id="skin_select">'+skin_skin_html+'</select>';
				//有皮肤状态
				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
			}else{				
				$.toaster({ priority : 'am-alert-warning', title : '失败', message :data.msg});
			}
			
			setTimeout('list()',500);
		}
	});
}
  $('#set_skin').click(function(){
  	set_skin(get_id(act_mode),act_mode);
  }); 
   $('#set_skin_2').click(function(){
   	 if(mode!='披风'){
   	 	act_mode='skin';
   	 }else{
   	 	act_mode='skin';
   	 }
  	set_skin(get_id(act_mode),act_mode);
  }); 
var mode='';
$('#skin_warehouse').find('a').on('opened.tabs.amui', function(e) {
  mode=$(this).text();
 if(mode!='披风'){
  	document.getElementById('set_skin').innerText='加入皮肤列表';
	act_mode='skin';
}else{
  	document.getElementById('set_skin').innerText='加入披风列表';
	act_mode='ape';
}
})
  $('#skin_info_button').click(function(){
  	$('#skin_info').modal('open');
  	if(mode!='披风'){
  		document.getElementById('set_skin').innerText='加入皮肤列表';
  		act_mode='skin';
  	}else{
  		document.getElementById('set_skin').innerText='加入披风列表';
  		act_mode='ape';
  	}
  	$.ajax({
  		type:"post",
  		url:"skin_ajax.php",
  		data:{
  			act:'get_skin_info',
  			groups:'user',
  			mode:'select_id',
  			select_mode:act_mode,
  			id:get_id(act_mode)
  		},
  		dataType:'json',
  		success:function(data){
  			if(data.mode=='1'){
  				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
  			}
  			if(data.mode=='2'){
  				document.getElementById('skin_info_img').src=data.skin_link;
  				document.getElementById('skin_info_name').value=data.skin_name;
  				document.getElementById('skin_md5').value=data.skin_md5;
  				document.getElementById('skin_info_updata_time').value=data.skin_time;
  				document.getElementById('skin_info_updata_name').value=data.skin_updata_user;
  				document.getElementById('set_skin').value=data.skin_id;
  				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
  			}
  		}
  	});
  });
function list(){
	$("select.image-picker").imagepicker({
		hide_select:true
	});
}
function exit_user(){
  	$.ajax({
  		type:"post",
  		url:"skin_ajax.php",
  		data:{
  			act:'exit_user'
  		},
  		dataType:'json',
  		success:function(data){
        	if(data.mode=='1'){
        		$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
        	}
        	if(data.mode=='2'){
        		$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
        		setTimeout('window.location.href="index.php"',2000);
        	}
  		}
  	});
}
$(document).ready(function(){
	load_skin_list('skin',0);
	load_skin_list('ape',0);
	setTimeout('list()',500);
	//开始排列皮肤
});
function get_id(act){
	if(act=="skin"){
		var select = document.getElementById("skin_select");
	}
	if(act=="ape"){
		var select = document.getElementById("ape_select");
	}
	var index = select.selectedIndex;
	if(select.innerText==''){
		$('#skin_info').modal('close');
		return false;
	}
	var value = select.options[index].value;
	return value;
}
function set_skin(id,mode){
	$.ajax({
		type:"post",
		url:"skin_ajax.php",
		data:{
			act:'add_skin',
			groups:'user',
			skin_id:id,
			mode:mode
		},
		dataType:'json',
		success:function(data){
  			if(data.mode=='1'){
  				$.toaster({ priority : 'am-alert-warning', title : '错误', message :data.msg});
  			}
  			if(data.mode=='2'){
  				$('#skin_info').modal('close');
  				$.toaster({ priority : 'am-alert-success', title : '成功', message :data.msg});
  			}
		}
	});
}