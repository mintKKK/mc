<?php
session_start();
if(empty($_SESSION['user_username']) or empty($_SESSION['user_password'])){
	exit(header("Location: index.php")); 
}
include('basis_html.php');
?>
<html>
	<head>
		<title>皮肤广场</title>
		<?php html_css(); ?>
		<link rel="stylesheet" href="css/skin_examples.css" />
		<link rel="stylesheet" href="css/skin_image_picker.css" />
	</head>
	<body style="background-image: url(images/bg[4].jpg);">
		<div class="am-g am-g-fixed">
			<div id="skin_user_body" style="padding-top: 10%;">
				<header class="am-topbar am-topbar-inverse am-animation-slide-top">
					<h1 class="am-topbar-brand"><a href="#">OneSkin</a></h1>		
					<div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
						<ul class="am-nav am-nav-pills am-topbar-nav">
							<li><a href="index.php">首页</a></li>
							<li><a href="skin_user/index.php">皮肤管理</a></li>
							<li class="am-active"><a href="#">皮肤广场</a></li>
							<li><a href="#" onclick="exit_user()">注销</a></li>
						</ul>
					</div>			
				</header>
				<!--导航条部分-->
				<div class="am-panel am-panel-default am-animation-slide-bottom">
					<div class="am-panel-bd">
						<div class="am-tabs" data-am-tabs="{noSwipe: 1}" id="skin_warehouse">
							<ul class="am-tabs-nav am-nav am-nav-tabs">
								<li class="am-active"><a href="#skin">皮肤</a></li>
								<li><a href="#ape">披风</a></li>
								<div class="am-cf">
									<div class="am-fr" style="margin-right: 3px;">
										<button type="button" class="am-btn am-btn-success am-radius" id="skin_info_button">皮肤信息</button>
									</div>	
									<div class="am-fr" style="margin-right: 3px;">
										<button type="button" class="am-btn am-btn-warning am-radius" id="set_skin_2">加入皮肤列表</button>
									</div>
								</div>								
							</ul>
							<div class="am-tabs-bd">
								<div class="am-tab-panel am-active" id="skin">
									<select class="image-picker" id="skin_select"></select>	<br>	
									<div class="am-cf">
										<div class="am-fl">
											<button type="button" class="am-btn am-btn-success" id="skin_up">上一页</button>
										</div>
										<div class="am-fr">
											<button type="button" class="am-btn am-btn-success" id="skin_down">下一页</button>
										</div>
									</div>
								</div>
								<div class="am-tab-panel" id="ape">
									<select class="image-picker" id="ape_select"></select><br>
									<div class="am-cf">
										<div class="am-fl">
											<button type="button" class="am-btn am-btn-success" id="ape_up">上一页</button>
										</div>
										<div class="am-fr">
											<button type="button" class="am-btn am-btn-success" id="ape_down">下一页</button>
										</div>
									</div>
								</div>
							</div>
						</div><br>
					</div>
				</div>					
			</div>
		</div>	
		<div id="skin_info" class="am-modal am-modal-no-btn" tabindex="-1">
			<div class="am-modal-dialog">
				<div class="am-modal-hd">
					<h3>皮肤信息</h3>
					<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
				</div>		
				<div class="am-modal-bd">
					<div class="am-g am-g-collapse">
						<div class="am-u-md-8">
							<div class="am-input-group">
								<span class="am-input-group-label">&nbsp;皮&nbsp;肤&nbsp;名&nbsp;</span>
								<input type="text" class="am-form-field" id="skin_info_name" disabled>
							</div><br>
							<div class="am-input-group">
								<span class="am-input-group-label">皮肤MD5</span>
								<input type="text" class="am-form-field" id="skin_md5" disabled>
							</div><br>								
							<div class="am-input-group">
								<span class="am-input-group-label">&nbsp;上&nbsp;传&nbsp;者&nbsp;</span>
								<input type="text" class="am-form-field" id="skin_info_updata_name" disabled>
							</div><br>	
							<div class="am-input-group">
								<span class="am-input-group-label">上传时间</span>
								<input type="text" class="am-form-field" id="skin_info_updata_time" disabled>
							</div><br>															
						</div>
						<div class="am-u-md-4">
							<img height="225" width="165" style="margin-left: 10px;" id="skin_info_img">
						</div>
						<div class="am-u-md-12">
							<button type="button" class="am-btn am-btn-primary am-radius am-btn-block" id="set_skin">加入皮肤列表</button>
						</div>
					</div>
				</div>			
			</div>
		</div>
		<!--皮肤信息框架-->
		<?php html_js(); ?>
		<script type="text/javascript" src="js/skin_world.js" ></script>
		<script type="text/javascript" src="js/skin/image-picker.min.js" ></script>
		<script type="text/javascript" src="js/toaster.js" ></script>
	</body>
</html>