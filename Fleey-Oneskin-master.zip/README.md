<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/Oneskin.ico" />OneSkin - 滑稽皮肤站
-------------------------------------

<img src="http://fleey-10010175.file.myqcloud.com/QQ%E5%9B%BE%E7%89%8720160215221456.gif" />
 
--------------------------------------
       Fleey与LSK完成滑稽皮肤站
      
          请务必准守开源协议！
          
        欢迎加入蜜蜂工作室与本人撕逼
             
       Oneskin为你提供安全可靠简约的界面
        
            群号：367428642  
        
             html&php Fleey and Lsk
             
            CustomSkin支持来自xfl03
        
                版本: 3.0.5

> 3.0.0版迎来全新的前端界面与完美的兼容性，兼容Beelogin,Authme,None
             
本项目中引用了一小部分的ncbql的代码,特此声明。

> 2.0.0版本于2016/4/15更新 

> 3.0.0版本于2016/6/19更新

> 3.0.3版本于2016/7/14.更新彻底限制皮肤披风格式问题 

> 3.0.4版本于2016/8/1更新 增加验证邮箱是否有效

> 3.0.5版本移除了一个可能存在的bug


感谢 狐狸 反馈错误，修复一个逻辑上的错误。

> 
使用声明
--------------------------------------
1. 遵守Apache2.0开源协议<br>
2. 遵守Mojang AB公司的EULA协议<br>
3. 不允许使用本皮肤站全部及部分源码搭建任何的公开的共有的皮肤站，个人非商业使用除外<br>
4. 不允许对本皮肤站版权的任何修改或将其隐藏<br>
5. 不允许在非作者允许下私自发布到其它网站<br>
6. Fleey保留最终解释权<br>
7. 1.0.5版本开始踏入兼容全版本mysql

预览地址
--------------------------------------
* 当然也可以用这个预览平台来代替某收费皮肤站
* [点击进入](http://fleey.org/skin/)
* fleey.org/skin 点击不鸟的= =自行链接
* 分流站点= =新增
--------------------------------------
登录界面
--------------------------------------
<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/%E7%99%BB%E9%99%86%E7%95%8C%E9%9D%A2.png" />
用户界面
--------------------------------------
<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/%E7%94%A8%E6%88%B7%E7%95%8C%E9%9D%A2.png" />
管理界面
--------------------------------------
<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/%E5%90%8E%E5%8F%B0.png" />
安装界面
--------------------------------------
<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/%E5%AE%89%E8%A3%85%E7%95%8C%E9%9D%A2.png" />
注册邮件
--------------------------------------
<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/%E9%82%AE%E4%BB%B6.png" />
皮肤广场
--------------------------------------
<img src="http://images-10010175.cos.myqcloud.com/oneskin%5B3.0%5D/%E7%9A%AE%E8%82%A4%E5%B9%BF%E5%9C%BA.png" />
下面是使用教程
--------------------------------------

如果进入管理员界面？ 打开你的网站/skin_admin  即可

Tip:如果你之前有安装Oneskin，很抱歉，这个3.0.0版本不兼容之前的Oneskin数据，需要你放弃之前的数据
需要手动删除之前的Oneskin创建的skin_config表。

首先你得下载这个项目源码,然后部署完毕。

接下来你就得用本文编辑器(Notepad++)打开skin—cofig.php配置数据库信息了。

当你配置完毕时,请用浏览器打开skin-installa.php如果你上一步配置失败这个安装会提示你。

现在你应该已经部署完毕了。马上登陆OneSkin试试吧。

CustomSkinLoader配置
--------------------------------------
#### 13.1及以上版本  
打开.minecraft/CustomSkinLoader/CustomSkinLoader.json  
在loadList下加入
```
    {
      "name": "OneSkin",
      "type": "CustomSkinAPI",
      "root": "http://您的皮肤站地址/skin_user/skin_json.php/"
    },
```
#### 13.1以下版本
打开.minecraft/CustomSkinLoader/skinurls.txt  
在新行写入  
```
http://您的皮肤站地址/show_skin/*.png  
```
打开.minecraft/CustomSkinLoader/capeurls.txt  
在新行写入  
```
http://您的皮肤站地址/show_ape/*.png  
```
UniSkinMod配置  
--------------------------------------
* https://yunpan.cn/cPwbfQGKRSBJy  访问密码 3e74
* 先启动首次客户端。等待生成配置文件。
* 游戏启动完毕后,关闭游戏,进入“.minecraft\config”文件
* 寻找“UniSkinMod.cfg”文件,使用文本编辑器打开。
* 修改成如图所示
<img src="http://fleey-10010175.file.myqcloud.com/QQ%E5%9B%BE%E7%89%8720160215234103.png"/>
* 第一个链接:"http://fleey.org/skin/show_skin/%s.png",当然如果你要自己构建需要改地址。
* 第二个链接："http://fleey.org/skin/skow_ape/%s.png".

一些小希望
--------------------------------------
希望大家能够使用这个皮肤站而不去搭建，因为这样可以省去很多麻烦。
并且皮肤站使用新技术"大数据"来写的。越多人用，上传越省事。

邮箱验证配置教程
--------------------------------------
先说一下，如果你没有后端验证邮箱，用户是不能够正常注册的。所以你得先绑定邮箱。

### 第一步
进入后台  你的网站地址/skin_admin  然后进入输入账号和密码 并且点击设置 即可

### 第二步  (我这边用QQ邮箱作为例子)

你需要打开你的QQ邮箱页面

<img src="http://i2.buimg.com/567571/a8b515b1dbb5dc0b.png" />

你需要点击设置QQ邮箱顶部的设置按钮 然后点击账户进入如下界面

<img src="http://i2.buimg.com/567571/a52615e59ba3a327.png" />

你需要往下滚动到这个界面 并且点击开启按钮

<img src="http://i2.buimg.com/567571/314797bb3c2843af.png" />

当你开启成功后你会看见这个界面  你需要记录下这个邮箱密码

<img src="http://i2.buimg.com/567571/7c6f4eca6adccfd3.png" />

现在你得回到皮肤站设置界面

<img src="http://i2.buimg.com/567571/6dde798fb402b5f5.png" />

最后你点击获取即可。获取时间可能比较久不过一般不会超过3分钟。

当你收到链接的时候，你只需要进入邮件需要进入的地址即可。

#### `顺便说一句如果你不想用qq邮箱或者担心限制，可以进入官方讨论群进行向我申请fleey.org的邮箱账号`  

# 更新历程
> 
1.Skin Me 无端端的商业化，从而诞生了制作Oneskin的念头 2016/2/10  
2.开始构建Oneskin的[1.0]版本，当时还仅仅只能达到单个皮肤效果，并且界面全是form表单提交 2016/2/21  
2.Oneskin[1.0]版本正式发布 2016/2/23  
3.Oneskin[1.4]版本是Oneskin[1.0]系列的最后版本推送 开始走向登录界面Ajax 2016/3/10  
4.Oneskin[2.0]版本开始构建 当时已经开始设想多皮肤管理系统 2016/3/25  
5.Oneskin[2.0]版本正式发布 已经达到伪邮箱验证与多皮肤管理界面 2016/4/17  
6.Oneskin[2.0.1]版本推送 推送皮肤广场功能 2016/4/21  
7.Oneskin[2.0.2]版本推送 推送Mysqli优化服务，数据库处理全面优化 2016/4/22  
8.Oneskin[3.0]版本开始构思 目标走向全面Ajax 优化数据处理与界面 2016/5/17  
9.Oneskin[3.0]版本正式发布 已经实现全面Ajax 优化数据处理与界面 2016/6/19  
10.Oneskin[4.0]版本开始构思 目标走向AngularJs 界面库走向Bootstrap 2016/8/22  

