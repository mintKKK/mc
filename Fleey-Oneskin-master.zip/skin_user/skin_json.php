<?php
//用于支持CustomSkinAPI
//ROOT/skin_user/skin_json.php/fleey.json
//ROOT/skin_user/skin_json.php/textures/67b184d996b7f79f34fef467b23efb47
$nav = $_SERVER["REQUEST_URI"];
$script_name = $_SERVER["SCRIPT_NAME"];
$nav = ereg_replace("^$script_name", "", urldecode($nav));
preg_match("/^\/(|textures\/)([a-zA-Z0-9_]{3,}?)(|\.json)$/",$nav,$matches);
if (($matches[1]!="textures/" and $matches[3]!=".json")) {
    header('HTTP/1.1 404 Not Found');
    exit(header("status: 404 Not Found"));
}
if ($matches[3]==".json") {
    $username = $matches[2];
    include ('../basis_html.php');
    $info_sql = config_read();
    //读取配置
    $mysqli = mysqli_connect($info_sql['db_host'], $info_sql['db_username'], $info_sql['db_password'], $info_sql['db_name'], $info_sql['db_port']);
    if (!$mysqli) {
        header('HTTP/1.1 404 Not Found');
        exit(header("status: 404 Not Found"));
    }
    $sql = 'select skinmd5,apemd5 from skinme where user=?';
    $stmt_1 = mysqli_prepare($mysqli, $sql);
    //置入指令
    //$exp = explode('.', $username);
    mysqli_stmt_bind_param($stmt_1, 's', $username);
    //置入参数
    mysqli_stmt_bind_result($stmt_1, $skin_md5, $ape_md5);
    //获取变量
    mysqli_stmt_execute($stmt_1);
    //执行命令
    mysqli_stmt_fetch($stmt_1);
    //实例化变量
    mysqli_stmt_close($stmt_1);
    //释放句柄
    $info['username'] = $username;
    if (empty($skin_md5) and empty($ape_md5)) {
        header('HTTP/1.1 404 Not Found');
        exit(header("status: 404 Not Found"));
    }
    if (!empty($skin_md5)) {
        $info['skins']['default'] = $skin_md5;
    }
    if (!empty($ape_md5)) {
        $info['cape'] = $ape_md5;
    }
    exit(json_encode($info));
}else{
    if(file_exists("../skin/".$matches[2].".png")){
        $skin_link="../skin/".$matches[2].".png";
        $fp=fopen($skin_link,"r")or die('出现了某些小错误[skin]');	
        Header("Content-type: image/png");
        exit(fread($fp,filesize($skin_link)));
    }
    if(file_exists("../ape/".$matches[2].".png")){
        $filename="../ape/".$matches[2].".png";
        $fp=fopen($filename,"r")or die('出现了某些小错误[ape]');	
        Header("Content-type: image/png");
        exit(fread($fp,filesize($filename)));	
    }	
    header('HTTP/1.1 404 Not Found');
    exit(header("status: 404 Not Found"));	
}
?>