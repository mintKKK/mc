<?php
include('../basis_html.php');
session_start();
$info_sql=config_read();//读取配置
$act=htmlspecialchars($_POST['act']);//获取状态
if(empty($act)){
	exit(json_encode(array('msg'=>'你貌似不在状态！','mode'=>'1')));
}
if(!file_exists('../skin_config.php')){
	exit(json_encode(array('msg'=>'貌似配置文件没有生成','mode'=>'1')));
}
$mysqli=mysqli_connect($info_sql['db_host'], $info_sql['db_username'], $info_sql['db_password'],$info_sql['db_name'],$info_sql['db_port']);
if(!$mysqli){
	exit(json_encode(array('msg'=>'Mysqli链接失败:'.mysqli_connect_error(),'mode'=>'1')));
}
if($act=='find_password'){//找回密码状态
	$code=strtolower($_POST['code']);
    $check_code=strtolower($_SESSION['check']);
	$find_password_username=$_POST['find_password_username'];//想找回密码的用户名
	$find_password_email=$_POST['find_password_email'];//想找回密码的邮箱
	if(empty($check_code)){
		exit(json_encode(array('mode'=>'1','msg'=>'验证码似乎有点问题,请刷新一下!')));
	}
	if($code!=$check_code){
		exit(json_encode(array('mode'=>'1','msg'=>'你的验证码貌似有点不对!')));
	}
	if(empty($find_password_email) or empty($find_password_username)){
		exit(json_encode(array('msg'=>'你似乎有东西忘记填了!','mode'=>'1')));
	}
	unset($_SESSION['check']);
	$msg=update_email($mysqli, $find_password_email, $find_password_username,$info_sql['mode']);
	exit(json_encode($msg));		
}
if($act=='login'){
	$login_username=$_POST['login_username'];
	$login_password=$_POST['login_password'];	
	$time=$_SESSION['info_login'];//获取原始数据
	if(!empty($time)){//判断验证码事件  小型风险控制系统
		if($time>time()){
			$code=strtolower($_POST['code']);
			$check_code=strtolower($_SESSION['check']);
			if(empty($code)){
				exit(json_encode(array('mode'=>'3','msg'=>'你貌似忘记填写验证码了!')));
			}
			if($code!=$check_code){
				exit(json_encode(array('mode'=>'1','msg'=>'你的验证码貌似有点不对!')));
			}
		}else{
			unset($_SESSION['info_login']);
		}
	}
	unset($_SESSION['check']);
	if(empty($login_password) or empty($login_username)){
		exit(json_encode(array('msg'=>'你似乎账号或者密码忘记填了','mode'=>'1')));
	}
	if(!preg_match($info_sql['regular_username'], $login_username)){
		exit(json_encode(array('msg' => '你用户名格式似乎有点不正确','mode' => "1")));
	}
	if(!preg_match(base64_decode($info_sql['regular_password']), $login_password)){
		exit(json_encode(array('msg' => '你密码格式似乎有点不正确','mode' => "1")));
	}
	if($info_sql['mode']=='none'){//使用内置登录模式
		$sql_none='select pass from skinme where user=?';//查询语句
		$stmt_none=$mysqli->prepare($sql_none);
		$stmt_none->bind_param('s',$login_username);//置入数据
		$stmt_none->execute();//执行sql
		$stmt_none->bind_result($none_password);
		$stmt_none->fetch();//获取sql数据
		$stmt_none->close();	
		if(empty($none_password)){
			$_SESSION['error_password']=$_SESSION['error_password']+1;
			if($_SESSION['error_password']>=3){
				$_SESSION['info_login']=time()+3200;//计算时间
				exit(json_encode(array('mode'=>'3','msg'=>'你的账号或密码不正确!')));
			}else{
				exit(json_encode(array('mode'=>'1','msg'=>'你的账号或密码不正确!')));
			}
		}
		if(!strcasecmp(md5($login_password),$none_password)){
			$_SESSION['user_username'] = $login_username;
			$_SESSION['user_password'] = $login_password;
			unset($_SESSION['check']);
			unset($_SESSION['number']);
			exit(json_encode(array('msg' => '登陆成功!过几秒后将为你转跳!','mode' => "2")));
		}else{
			$_SESSION['error_password']=$_SESSION['error_password']+1;
			if($_SESSION['error_password']>=3){
				$_SESSION['info_login']=time()+3200;//计算时间
				exit(json_encode(array('mode'=>'3','msg'=>'你的账号或密码不正确!')));
			}else{
				exit(json_encode(array('mode'=>'1','msg'=>'你的账号或密码不正确!')));
			}
		}
	}
	if($info_sql['mode']=='authme'){//使用authme登录模式
		if(!empty($info_sql['table']) or !empty($info_sql['realname']) or !empty($info_sql['password']) or !empty($info_sql['username'])){//再次判断配置项无错误
			$sql_authme="select ".$info_sql['password']." from ".$info_sql['table']." where ".$info_sql['realname']."=?";//查询语句
			$stmt_authme=$mysqli->prepare($sql_authme);
			$stmt_authme->bind_param('s', $login_username);//sql预处理交互
			$stmt_authme->execute();//执行sql
			$stmt_authme->bind_result($authme_password);
			$stmt_authme->fetch();//获取sql数据
			$stmt_authme->close();	
			if(empty($authme_password)){
				$_SESSION['error_password']=$_SESSION['error_password']+1;
				if($_SESSION['error_password']>=3){
					$_SESSION['info_login']=time()+3200;//计算时间
					exit(json_encode(array('mode'=>'3','msg'=>'你的账号或密码不正确!')));
				}else{
					exit(json_encode(array('mode'=>'1','msg'=>'你的账号或密码不正确!')));
				}
			}else{
				$str_arr=explode("$", $authme_password);//分割字符串
				$salt=$str_arr[2];//获取散列
				$sha256_password = hash('sha256', $login_password);
				$sha256_password = hash('sha256',$sha256_password.$salt);//计算出密码
				if(!strcasecmp($sha256_password, $str_arr[3])){
					$sql_oneskin="select pass from skinme where user=?";//查询语句
					$stmt_oneskin=$mysqli->prepare($sql_oneskin);
					$stmt_oneskin->bind_param('s',$login_username);
					$stmt_oneskin->execute();
					$stmt_oneskin->bind_result($oneskin_password);
					$stmt_oneskin->fetch();
					$stmt_oneskin->close();
					if(empty($oneskin_password)){
						$sql_oneskin_new="INSERT INTO skinme (user,pass,email) VALUES (?,?,?)";//sql注册部分
						$stmt_oneskin_new=$mysqli->prepare($sql_oneskin_new);
						$md5_password=md5($login_password);
						$reg_email=NULL;
						$stmt_oneskin_new->bind_param('sss',$login_username,$md5_password,$reg_email);
						$stmt_oneskin_new->execute();//执行sql
						$stmt_oneskin_new->close();
					}
					$_SESSION['user_username'] = $login_username;
					$_SESSION['user_password'] = $login_password;
					unset($_SESSION['number']);
					exit(json_encode(array('msg' => '登陆成功!过几秒后将为你转跳!','mode' => "2")));
				}else{
					$_SESSION['error_password']=$_SESSION['error_password']+1;
					if($_SESSION['error_password']>=3){
						$_SESSION['info_login']=time()+3200;//计算时间
						exit(json_encode(array('mode'=>'3','msg'=>'你的账号或密码不正确!')));
					}else{
						exit(json_encode(array('mode'=>'1','msg'=>'你的账号或密码不正确!')));
					}
				}
            }
        }
	}
	if($info_sql['mode']=='beelogin'){//使用beelogin登录模式
		if(!empty($info_sql['table']) or !empty($info_sql['username']) or !empty($info_sql['password']) or !empty($info_sql['password_salt'])){
			$sql_beelogin="select ".$info_sql['password'].",".$info_sql['password_salt']." from ".$info_sql['table']." where ".$info_sql['username']."=?";//查询语句
			$stmt_beelogin=$mysqli->prepare($sql_beelogin);
			$stmt_beelogin->bind_param('s', $login_username);//sql预处理交互
			$stmt_beelogin->execute();//执行sql
			$stmt_beelogin->bind_result($beelogin_password,$beelogin_password_salt);		
			$stmt_beelogin->fetch();//获取sql数据
			$stmt_beelogin->close();			
			if(empty($beelogin_password)){
				$_SESSION['error_password']=$_SESSION['error_password']+1;
				if($_SESSION['error_password']>=3){
					$_SESSION['info_login']=time()+3200;//计算时间
					exit(json_encode(array('mode'=>'3','msg'=>'你的账号或密码不正确!')));
				}else{
					exit(json_encode(array('mode'=>'1','msg'=>'你的账号或密码不正确!')));
				}	
			}else{
				$beelogin_password_md5=md5(md5($login_password).$beelogin_password_salt);//计算结果
				if(!strcasecmp($beelogin_password_md5, $beelogin_password)){
					$sql_oneskin="select pass from skinme where user=?";//查询语句
					$stmt_oneskin=$mysqli->prepare($sql_oneskin);
					$stmt_oneskin->bind_param('s',$login_username);
					$stmt_oneskin->execute();
					$stmt_oneskin->bind_result($oneskin_password);
					$stmt_oneskin->fetch();
					$stmt_oneskin->close();
					if(empty($oneskin_password)){
						$sql_oneskin_new="INSERT INTO skinme (user,pass,email) VALUES (?,?,?)";//sql注册部分
						$stmt_oneskin_new=$mysqli->prepare($sql_oneskin_new);
						$md5_password=md5($login_password);
						$reg_email=NULL;
						$stmt_oneskin_new->bind_param('sss',$login_username,$md5_password,$reg_email);
						$stmt_oneskin_new->execute();//执行sql
						$stmt_oneskin_new->close();
					}				
					$_SESSION['user_username'] = $login_username;
					$_SESSION['user_password'] = $login_password;
					unset($_SESSION['number']);
					exit(json_encode(array('msg' => '登陆成功!过几秒后将为你转跳!','mode' => "2")));			
				}else{
					$_SESSION['error_password']=$_SESSION['error_password']+1;
					if($_SESSION['error_password']>=3){
						$_SESSION['info_login']=time()+3200;//计算时间
						exit(json_encode(array('mode'=>'3','msg'=>'你的账号或密码不正确!')));
					}else{
						exit(json_encode(array('mode'=>'1','msg'=>'你的账号或密码不正确!')));
					}
				}
            }			
		}
	}
}
if($act=='check_username'){
	$check_username=$_POST['check_username'];
	if(empty($check_username)){
		exit(json_encode(array('msg'=>'你在搞什么鬼？','mode'=>'1')));
	}
	if($_SESSION['error_number']>=3){
		exit(json_encode(array('msg'=>'冷静下,你有点疯狂!','mode'=>'1')));
	}
	if(!preg_match($info_sql['regular_username'], $check_username)){
		exit(json_encode(array('msg' => '你用户名格式似乎有点不正确','mode' => "1")));
	}
	if($info_sql['mode']=='none'){//使用内置模式
		$sql_none='select pass from skinme where user=?';//查询语句
		$stmt_none=$mysqli->prepare($sql_none);
		$stmt_none->bind_param('s',$check_username);//置入数据
		$stmt_none->execute();//执行sql
		$stmt_none->bind_result($none_password);
		$stmt_none->fetch();//获取sql数据
		$stmt_none->close();
		$_SESSION['error_number']=$_SESSION['error_number']+1;
		if(empty($none_password)){
			exit(json_encode(array('msg'=>'这个用户名没有被注册！','mode'=>'2')));
		}
		exit(json_encode(array('msg'=>'这个用户名被人捷足先登了','mode'=>'1')));
	}
	if($info_sql['mode']=='authme'){//使用authme模式
	    $check_username=strtolower($check_username);
		$sql_authme="select ".$info_sql['password']." from ".$info_sql['table']." where ".$info_sql['realname']."=?";//查询语句
		$stmt_authme=$mysqli->prepare($sql_authme);
		$stmt_authme->bind_param('s', $check_username);//sql预处理交互
		$stmt_authme->execute();//执行sql
		$stmt_authme->bind_result($authme_password);
		$stmt_authme->fetch();//获取sql数据
		$stmt_authme->close();
		$_SESSION['error_number']=$_SESSION['error_number']+1;
		if(empty($authme_password)){
			exit(json_encode(array('msg'=>'这个用户名没有被注册！','mode'=>'2')));
		}
		exit(json_encode(array('msg'=>'这个用户名被人捷足先登了','mode'=>'1')));					
	}
	if($info_sql['mode']=='beelogin'){//使用beelogin模式
		$sql_beelogin="select ".$info_sql['password'].",".$info_sql['password_salt']." from ".$info_sql['table']." where ".$info_sql['username']."=?";//查询语句
		$stmt_beelogin=$mysqli->prepare($sql_beelogin);
		$stmt_beelogin->bind_param('s', $check_username);//sql预处理交互
		$stmt_beelogin->execute();//执行sql
		$stmt_beelogin->bind_result($beelogin_password,$beelogin_password_salt);		
		$stmt_beelogin->fetch();//获取sql数据
		$stmt_beelogin->close();	
		$_SESSION['error_number']=$_SESSION['error_number']+1;
		if(empty($beelogin_password)){
			exit(json_encode(array('msg'=>'快注册吧！你这个用户名将属于你！','mode'=>'2')));
		}	
		exit(json_encode(array('msg'=>'这个用户名被人捷足先登了','mode'=>'1')));			
	}
}
if($act=='register'){//注册模式
	$register_username=$_POST['register_username'];//获取注册用户名
	$register_password=$_POST['register_password'];//获取注册密码
	$register_email=$_POST['register_email'];//获取注册邮箱
	$register_code=strtolower($_POST['register_code']);//获取注册时验证码
	$check_code=strtolower($_SESSION['check']);
	if(empty($register_password) or empty($register_username) or empty($register_email) or empty($register_code)){
		exit(json_encode(array('msg'=>'你似乎有东西忘记填了','mode'=>'1')));
	}
	if(empty($check_code)){
		exit(json_encode(array('mode'=>'1','msg'=>'验证码似乎有点问题,请刷新一下!')));
	}
	if($register_code!=$check_code){
		exit(json_encode(array('msg' => '你验证码似乎有点不正确','mode' => "1")));
	}
	if(!preg_match($info_sql['regular_username'], $register_username)){
		exit(json_encode(array('msg' => '你用户名格式似乎有点不正确','mode' => "1")));
	}
	if(!preg_match(base64_decode($info_sql['regular_password']), $register_password)){
		exit(json_encode(array('msg' => '你密码格式似乎有点不正确','mode' => "1")));
	}
	if(!preg_match(base64_decode($info_sql['regular_email']), $register_email)){
		exit(json_encode(array('msg' => '你的邮箱格式似乎有点不正确','mode' => "1")));
	}	
	unset($_SESSION['check']);
	$sql_none='select time from skin_email where email=?';//查询语句
	$stmt_none=$mysqli->prepare($sql_none);//置入指令
	$stmt_none->bind_param('s',$register_email);//查询用户名
	$stmt_none->execute();//执行命令
	$stmt_none->bind_result($email_time);//置入数据
	$stmt_none->fetch();//获取sql数据
	$stmt_none->close();
	if($email_time>time()){
		exit(json_encode(array('msg'=>'这个邮箱不久前才发送邮件呢','mode'=>'1')));
	}
	if($info_sql['mode']=='none'){//使用内置模式
		$sql_none='select time from skin_email where email=?';//查询语句
		$stmt_none=$mysqli->prepare($sql_none);//置入指令
		$stmt_none->bind_param('s',$register_email);//查询用户名
		$stmt_none->execute();//执行命令
		$stmt_none->bind_result($email_time);//置入数据
		$stmt_none->fetch();//获取sql数据
		$stmt_none->close();
		if($email_time>time()){
			exit(json_encode(array('msg'=>'这个邮箱不久前才发送邮件呢','mode'=>'1')));
		}
		$sql_none='select pass from skinme where user=?';//查询语句
		$stmt_none=$mysqli->prepare($sql_none);//置入指令
		$stmt_none->bind_param('s',$register_username);//查询用户名
		$stmt_none->execute();//执行命令
		$stmt_none->bind_result($none_password);//置入数据
		$stmt_none->fetch();//获取sql数据
		$stmt_none->close();
		if(!empty($none_password)){
			exit(json_encode(array('msg'=>'这个用户名似乎被注册了!','mode'=>'1')));
		}	
		//用户查询部分结束		
		if(skin_email($mysqli,$register_username,$register_password,$register_email,$info_sql)){
			exit(json_encode(array('msg'=>'发送成功成耐心等待邮件的到来!','mode'=>'2')));
		}else{
			exit(json_encode(array('msg'=>'发送失败!请重试','mode'=>'1')));
		}
		//邮件表单验证部分开始
		
	}
	if($info_sql['mode']=='authme'){//使用authme模式
		if(!empty($info_sql['table']) or !empty($info_sql['realname']) or !empty($info_sql['username']) or !empty($info_sql['password'])){		
			$sql_authme="select ".$info_sql['password']." from ".$info_sql['table']." where ".$info_sql['username']."=? or ".$info_sql['realname'].'=?';//查询语句
			$stmt_authme_reg=$mysqli->prepare($sql_authme);
			$name=strtolower($register_username);
			$stmt_authme_reg->bind_param('s',$register_username,$name);//查询用户名
			$stmt_authme_reg->execute();//执行sql
			$stmt_authme_reg->bind_result($authme_password_reg);
			$stmt_authme_reg->fetch();//获取sql数据
			$stmt_authme_reg->close();			
			if(empty($authme_password_reg)){
				$sql_none='select pass from skinme where email=?';//查询语句
				$stmt_none=$mysqli->prepare($sql_none);//置入指令
				$stmt_none->bind_param('s',$register_email);//查询用户名
				$stmt_none->execute();//执行命令
				$stmt_none->bind_result($none_password);//置入数据
				$stmt_none->fetch();//获取sql数据
				$stmt_none->close();
				if(!empty($none_password)){
					exit(json_encode(array('msg'=>'这个邮箱似乎被人注册了哟~!','mode'=>'1')));
                }	
                if(skin_email($mysqli,$register_username,$register_password,$register_email,$info_sql)){
                	exit(json_encode(array('msg'=>'发送成功成耐心等待邮件的到来!','mode'=>'2')));
				}else{
					exit(json_encode(array('msg'=>'发送失败!请重试','mode'=>'1')));
				}							
			}else{
				exit(json_encode(array('msg'=>'这个用户名似乎被注册了!','mode'=>'1')));
			}
		}else{
			exit(json_encode(array('msg'=>'配置文件出错,请重新安装!','mode'=>'1')));
		}
	}
	if($info_sql['mode']=='beelogin'){//使用beelogin模式登录
		if(!empty($info_sql['table']) or !empty($info_sql['username']) or !empty($info_sql['password']) or !empty($info_sql['password_salt'])){
			$sql_beelogin = 'select '.$info_sql['password'].','.$info_sql['password_salt']." from ".$info_sql['table']." where ".$info_sql['username']."=?";//sql语句
			$stmt_beelogin_reg=$mysqli->prepare($sql_beelogin);
			$stmt_beelogin_reg->bind_param('s', $register_username);//sql预处理交互
			$stmt_beelogin_reg->execute();//执行sql
			$stmt_beelogin_reg->bind_result($beelogin_password_reg,$beelogin_password_salt_reg);
			$stmt_beelogin_reg->fetch();//获取sql数据
			$stmt_beelogin_reg->close();		
			if(empty($beelogin_password_reg)){
				$sql_none='select pass from skinme where email=?';//查询语句
				$stmt_none=$mysqli->prepare($sql_none);//置入指令
				$stmt_none->bind_param('s',$register_email);//查询用户名
				$stmt_none->execute();//执行命令
				$stmt_none->bind_result($none_password);//置入数据
				$stmt_none->fetch();//获取sql数据
				$stmt_none->close();
				if(!empty($none_password)){
					exit(json_encode(array('msg'=>'这个邮箱似乎被人注册了哟~!','mode'=>'1')));
                }	
                if(skin_email($mysqli,$register_username,$register_password,$register_email,$info_sql)){
                	exit(json_encode(array('msg'=>'发送成功成耐心等待邮件的到来!','mode'=>'2')));
				}else{
					exit(json_encode(array('msg'=>'发送失败!请重试','mode'=>'1')));
				}								
			}else{
				exit(json_encode(array('msg'=>'这个用户名似乎被注册了!','mode'=>'1')));
			}	
		}else{
			exit(json_encode(array('msg'=>'配置文件出错,请重新安装!','mode'=>'1')));
		}		
	}
}
mysqli_close($mysqli);
exit(json_encode(array('msg'=>'你状态貌似有点不对劲！','mode'=>'1')));
function skin_email($mysqli,$username,$password,$email,$info_config){
	$random=getRandChar('9');//生成随机9位字符
	$time=time()+1800;//获取当前时间戳
	$str_json['username']=$username;//存储用户名
	$str_json['password']=$password;//存储用户密码
	$json=json_encode($str_json);
	$sql='select user from skin_email where email=?';
	$stmt_email=$mysqli->prepare($sql);
	$stmt_email->bind_param('s',$email);
	$stmt_email->execute();
	$stmt_email->bind_result($email_user);
	$stmt_email->fetch();
	$stmt_email->close();
	$smtp_config=object_array(json_decode(get_mysqli_config($mysqli,'smtp_config')));
	if($smtp_config['smtp_ssl']=='yes'){
		$if_ssl=TRUE;
	}else{
		$if_ssl=FALSE;
	}
	$c=explode('/',get_dirname());
	for($i=0; $i<=count($c)-2; $i++) { 
		$url.=$c[$i].'/';
	}
	$url=$url.'skin_just.php?act=register&key='.$random; 
	if(empty($info_sql['title'])){
		$k='Oneskin';
	}else{
		$k=$info_sql['title'];
	}
	$a=send_email($email,$if_ssl,$smtp_config['smtp_host'],$smtp_config['smtp_port'],$smtp_config['smtp_username'],$smtp_config['smtp_password'],'欢迎你注册，'.$username,html_email($username,$k, $url));
	if($a==FALSE){
		return $a;
	}
	if(empty($email_user)){
		$sql="INSERT INTO skin_email(user,email,time,code) VALUES(?,?,?,?)";//sql注册部分
		$stmt_3=$mysqli->prepare($sql);
		$stmt_3->bind_param('ssss',$json,$email,$time,$random);
		$stmt_3->execute();//执行sql
		$stmt_3->close();	
	}else{
		$sql = "UPDATE skin_email SET time=?,code=?,user=? where email=?";//更新玩家邮箱设置
		$stmt_user=$mysqli->prepare($sql);		
		$stmt_user->bind_param("ssss",$time,$random,$json,$email);
		$stmt_user->execute();
		$stmt_user->close();			
	}
	return $a;
}
function update_email($mysqli,$email,$username,$mode){
	if(empty($mysqli) or empty($email) or empty($username) or empty($mode)){
		$info['mode']='1';
		$info['msg']='出现内部错误500';
		return $info;
	}

	$sql_none='select user from skinme where email=?';//查询语句
	$stmt_none=$mysqli->prepare($sql_none);//置入指令
	$stmt_none->bind_param('s',$email);//查询用户名
	$stmt_none->execute();//执行命令
	$stmt_none->bind_result($none_username);//置入数据
	$stmt_none->fetch();//获取sql数据
	$stmt_none->close();
	if($username!=$none_username){
		$info['mode']='1';
		$info['msg']='你的用户名和找回密码邮箱不匹配!';
		return $info;
	}else{
		$sql='select user,time from skin_email where email=?';
		$stmt_email=$mysqli->prepare($sql);
		$stmt_email->bind_param('s',$email);
		$stmt_email->execute();
		$stmt_email->bind_result($email_user,$email_time);
		$stmt_email->fetch();
		$stmt_email->close();	
		if($email_time>time()){
			$info['mode']='1';
			$info['msg']='这个邮箱不久前才刚发送过邮件呢!';
			return $info;			
		}
		$random=getRandChar('9');//生成随机9位字符
		$time=time()+1800;//获取当前时间戳
		$str_json['username']=$username;//存储用户名
		$str_json['mode']=$mode;//存储模式
		$str_json['act']='find_password';//存储状态
		$json=json_encode($str_json);
		$smtp_config=object_array(json_decode(get_mysqli_config($mysqli,'smtp_config')));
		if($smtp_config['smtp_ssl']=='yes'){
			$if_ssl=TRUE;
		}else{
			$if_ssl=FALSE;
		}
		$c=explode('/',get_dirname());
		for($i=0; $i<=count($c)-2; $i++) {
			 $url.=$c[$i].'/';
		}
		$url=$url.'skin_just.php?act=find_password&key='.$random; 
		$a=send_email($email,$if_ssl,$smtp_config['smtp_host'],$smtp_config['smtp_port'],$smtp_config['smtp_username'],$smtp_config['smtp_password'],'关于你找回密码的事情，'.$username,html_email($username,'Oneskin', $url));
		if($a==FALSE){
			$info['mode']='1';
			$info['msg']='发送邮件失败,请重试!';
			return $info;
		}
		if(empty($email_user)){
			$sql="INSERT INTO skin_email(user,email,time,code) VALUES(?,?,?,?)";//sql注册部分
			$stmt_3=$mysqli->prepare($sql);
			$stmt_3->bind_param('ssss',$json,$email,$time,$random);
			$stmt_3->execute();//执行sql
			$stmt_3->close();			
		}else{
			$sql = "UPDATE skin_email SET time=?,code=?,user=? where email=?";//更新玩家邮箱设置
			$stmt_user=$mysqli->prepare($sql);		
			$stmt_user->bind_param("ssss",$time,$random,$json,$email);
			$stmt_user->execute();
			$stmt_user->close();			
		}
		$info['mode']='2';
		$info['msg']='发送成功!请耐心等候邮件的到来';
		return $info;
	}
}
?>