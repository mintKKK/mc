<?php
session_start();
if(empty($_SESSION['user_username']) or empty($_SESSION['user_password'])){
	exit(header("Location: ../index.php")); 
}
include('../basis_html.php');//载入基础文件
?>
<!doctype html>
<html class="no-js fixed-layout">
	<head>
		<title>用户中心</title>
		<meta name="renderer" content="webkit">
		<?php html_inside_css(); ?>
		<link rel="stylesheet" type="text/css" href="../css/skin_user.css"/>
		<link rel="stylesheet" href="../css/skin_examples.css" />
		<link rel="stylesheet" href="../css/skin_image_picker.css" />
	</head>
	<body>
		<div class="am-g am-g-fixed">
			<div id="skin_user_body" style="padding-top: 10%;">
				<header class="am-topbar am-topbar-inverse am-animation-slide-top">
					<h1 class="am-topbar-brand"><a href="#">OneSkin</a></h1>		
					<div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
						<ul class="am-nav am-nav-pills am-topbar-nav">
							<li><a href="../index.php">首页</a></li>
							<li class="am-active"><a href="#">皮肤管理</a></li>
							<li><a href="../skin_world.php">皮肤广场</a></li>
							<li><a href="#" onclick="exit_user()">注销</a></li>
						</ul>
					</div>			
				</header>
				<!--导航条部分-->
				<div id="body_main" style="padding: 10px;">
					<div class="am-u-md-7 skin-main am-animation-slide-left" style="background: white;box-shadow:2px 2px 10px #909090;padding: 10px;border-radius:2px;margin-bottom: 3%;">
						<blockquote><p class="am-text-sm am-text-truncate am-sans-serif">皮肤仓库</p></blockquote>
							<div class="am-tabs" data-am-tabs="{noSwipe: 1}" id="skin_warehouse">
								<ul class="am-tabs-nav am-nav am-nav-tabs">
									<li class="am-active"><a href="#skin_skin">皮肤</a></li>
									<li><a href="#skin_ape">披风</a></li>
									<div class="am-cf">
										<div class="am-fr" style="margin-right: 3px;">
											<button type="button" class="am-btn am-btn-primary am-radius" id="skin_info_button">皮肤信息</button>
										</div>																			
										<div class="am-fr" style="margin-right: 3px;">
											<button type="button" class="am-btn am-btn-success am-radius" data-am-modal="{target: '#updata_pic',width: 450, height: 380}">上传</button>
										</div>
									</div>
									<!--菜单部分-->
								</ul>
								<div class="am-tabs-bd">
									<div class="am-tab-panel am-fade am-in am-active" id="skin_skin">
										<select class="image-picker" id="skin_select">
										</select>										
									</div>
									<div class="am-tab-panel am-fade am-in" id="skin_ape">
										<select class="image-picker" id="ape_select">
										</select>											
									</div>									
								</div>								
							</div>
							<button type="button" data-am-modal="{target: '#updata_help',width: 750, height: 380}" class="am-btn am-btn-primary am-btn-block btn-loading-example">查看上传帮助</button>
					</div>
					<div class="am-u-md-4 skin-sidebar am-animation-slide-right" style="background: white;box-shadow:2px 2px 10px #909090;padding: 10px;border-radius:2px;max-width: 320px;">
						<h1 style="text-align:center;color:#3498DB;"><?php echo $_SESSION['user_username']; ?></h1>
						<div id="skinpreview" class="warp" style="margin:0 auto;width: 310px;max-width: 100%;max-height: 100%;"></div>
						<!--皮肤框架-->
					</div>
				</div>
			</div>
		</div>
		<div id="updata_pic" class="am-modal am-modal-no-btn" tabindex="-1">
			<div class="am-modal-dialog">
				<div class="am-modal-hd">
					<h3>上传中心</h3>
					<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
				</div>
				<div class="am-modal-bd">
					<div class="am-g am-g-collapse">
						<div class="am-u-md-8">
							<div class="am-input-group">
								<span class="am-input-group-label">当前模式</span>
								<div style="background: whitesmoke;Border:1px solid #95A5A6;height: 38px;">
									<label class="am-radio-inline">
										<input type="radio" name="mode" value="skin" data-am-ucheck>皮肤
									</label>
									<label class="am-radio-inline">
										<input type="radio" name="mode" value="ape" data-am-ucheck>披风
									</label>
								</div>	
							</div><br>					
							<div class="am-input-group">
								<span class="am-input-group-label">&nbsp;皮&nbsp;肤&nbsp;名&nbsp;</span>
								<input type="text" class="am-form-field" id="skin_name">
							</div><br>
							<div class="am-form-group am-form-file">
								<button type="button" class="am-btn am-btn-primary am-btn-block">
									<i class="am-icon-cloud-upload"></i>&nbsp;&nbsp;&nbsp;
									选择要上传的皮肤
								</button>
								<div id="updata_file">
									<input id="file_pic" type="file" name="file_pic" multiple>
								</div>
							</div>					
						</div>				
						<div class="am-u-md-4">
							<img src="../images/ape_1.png" width="120" height="240" id="skin_img" >
						</div>
						<div class="am-u-md-12">
							<button type="button" style="border:none;background:#f8f8f8;font-size:14px;align:right;" data-am-modal="{target: '#updata_help',width: 750, height: 380}">要了解正确的皮肤样式?点击这里</button>
							<button type="button" class="am-btn am-btn-primary am-btn-block btn-loading-example" data-am-loading="{spinner: 'circle-o-notch', loadingText: '加载中...'}" id="updata_pic_button">上传</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--上传皮肤框架-->
		<div id="updata_help" class="am-modal am-modal-no-btn" tabindex="-1">
			<div class="am-modal-dialog">
				<div class="am-modal-hd">
					<h3>上传帮助</h3>
					<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
				</div>
				<div class="am-modal-bd">
				<p>请您根据下方表格来确认您所要上传的皮肤是正确的。<br>
				只有上传正确的皮肤才能在游戏内正常显示！</p>
				<table class="am-table am-table-striped am-table-hover">
				<thead><tr><th>正确</th><th>正确</th><th>正确</th><th>错误</th><th>错误</th></tr></thead>
					<tbody id="skin_table"><tr><td><img class="am-radius mCS_img_loaded" src="../images/zq1.png"></td><td><img class="am-radius mCS_img_loaded" src="../images/zq2.png"></td><td><img class="am-radius mCS_img_loaded" src="../images/zq3.png"></td><td><img class="am-radius mCS_img_loaded" src="../images/cw1.png"></td><td><img class="am-radius mCS_img_loaded" src="../images/cw2.png" width="160px" height="142px"></td></tr>
					</tbody>
				</table>
					
				</div>
			</div>
		</div>
		<!--上传皮肤帮助框架-->
		<div id="skin_info" class="am-modal am-modal-no-btn" tabindex="-1">
			<div class="am-modal-dialog">
				<div class="am-modal-hd">
					<h3>皮肤信息</h3>
					<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
				</div>		
				<div class="am-modal-bd">
					<div class="am-g am-g-collapse">
						<div class="am-u-md-8">
							<div class="am-input-group">
								<span class="am-input-group-label">&nbsp;皮&nbsp;肤&nbsp;名&nbsp;</span>
								<input type="text" class="am-form-field" id="skin_info_name" disabled>
							</div><br>
							<div class="am-input-group">
								<span class="am-input-group-label">皮肤MD5</span>
								<input type="text" class="am-form-field" id="skin_md5" disabled>
							</div><br>								
							<div class="am-input-group">
								<span class="am-input-group-label">&nbsp;上&nbsp;传&nbsp;者&nbsp;</span>
								<input type="text" class="am-form-field" id="skin_info_updata_name" disabled>
							</div><br>	
							<div class="am-input-group">
								<span class="am-input-group-label">上传时间</span>
								<input type="text" class="am-form-field" id="skin_info_updata_time" disabled>
							</div><br>															
						</div>
						<div class="am-u-md-4">
							<img height="225" width="165" style="margin-left: 10px;" id="skin_info_img">
						</div>
						<div class="am-u-md-12">
							<div class="am-btn-group">
								<br>
								<button type="button" class="am-btn am-btn-primary am-radius" id="set_skin">设置为主皮肤</button>
								<button type="button" class="am-btn am-btn-danger am-radius" id="del_skin">删除</button>
							</div>
						</div>
					</div>
				</div>			
			</div>
		</div>
		<!--皮肤信息框架-->
		<!--背景部分-->
		<div style="position:absolute; width:100%; height:100%; z-index:-1; left:0; top:0;">      
            <img src="../images/bg[3].jpg" height="100%" width="100%" style="left:0; top:0;">   
        </div>
		<?php html_inside_js(); ?>
		<script type="text/javascript" src="../js/skin/image-picker.min.js" ></script>
		<script type="text/javascript" src="../js/skin/ajaxfileupload.js" ></script>
		<script type="text/javascript" src="../js/skin/skin_three.js" ></script>
		<script type="text/javascript" src="../js/toaster.js" ></script>
		<script type="text/javascript" src="../js/skin/skin_preview.js" ></script>
		<script type="text/javascript" src="../js/skin_user.js" ></script>
	</body>
</html>